---
name: Flutter validation
description: Validation constraint for the exported Haier Flutter source in this workspace.
---

The workspace does not currently expose a Flutter or Dart SDK on PATH, so the
`haier/` export cannot be checked with `flutter analyze` here.

**Why:** The source is an exported FlutterFlow app while the configured
workflows are TypeScript services; Dart validation must happen in a Flutter
capable environment.

**How to apply:** Continue to use static reference checks and archive integrity
checks locally, then run `flutter analyze` and a device/emulator smoke test
before publishing the Flutter build.