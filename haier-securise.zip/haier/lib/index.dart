// Export pages
export '/auth/auth2/auth2_widget.dart' show Auth2Widget;
export '/auth/auth1/auth1_widget.dart' show Auth1Widget;
export '/menu/acceuil/acceuil_widget.dart' show AcceuilWidget;
export '/menu/produits/produits_widget.dart' show ProduitsWidget;
export '/autre/detail_produit/detail_produit_widget.dart'
    show DetailProduitWidget;
export '/autre/produit_user/produit_user_widget.dart' show ProduitUserWidget;
export '/menu/invitation/invitation_widget.dart' show InvitationWidget;
export '/autre/equipe/equipe_widget.dart' show EquipeWidget;
export '/menu/profile/profile_widget.dart' show ProfileWidget;
export '/transactions/recharge/recharge_widget.dart' show RechargeWidget;
export '/transactions/retrait/retrait_widget.dart' show RetraitWidget;
export '/autre/actualiter/actualiter_widget.dart' show ActualiterWidget;
export '/autre/partage_capture/partage_capture_widget.dart'
    show PartageCaptureWidget;
export '/autre/loterie/loterie_widget.dart' show LoterieWidget;
export '/transactions/historique_depot/historique_depot_widget.dart'
    show HistoriqueDepotWidget;
export '/auth/inscription/inscription_widget.dart' show InscriptionWidget;
export '/transactions/historique_retrait/historique_retrait_widget.dart'
    show HistoriqueRetraitWidget;
export '/admin0/admin_acceuil/admin_acceuil_widget.dart'
    show AdminAcceuilWidget;
export '/admin0/admin_depots/admin_depots_widget.dart' show AdminDepotsWidget;
export '/admin0/admin_retrait/admin_retrait_widget.dart'
    show AdminRetraitWidget;
export '/admin0/admin_users/admin_users_widget.dart' show AdminUsersWidget;
export '/om/om_widget.dart' show OmWidget;
export '/mtn/mtn_widget.dart' show MtnWidget;
