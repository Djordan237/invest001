import 'package:flutter/material.dart';
import 'backend/supabase/supabase.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  String _nomProduits = 'Choisir un produit';
  String get nomProduits => _nomProduits;
  set nomProduits(String value) {
    _nomProduits = value;
  }

  String _methodeRetrait = 'Orange Money';
  String get methodeRetrait => _methodeRetrait;
  set methodeRetrait(String value) {
    _methodeRetrait = value;
  }
}
