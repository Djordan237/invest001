import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '/auth/supabase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';

/// Prevents admin screens from rendering before the user's role has been
/// checked against the authenticated Supabase user.
class AdminGuard extends StatefulWidget {
  const AdminGuard({super.key, required this.child});

  final Widget child;

  @override
  State<AdminGuard> createState() => _AdminGuardState();
}

class _AdminGuardState extends State<AdminGuard> {
  late final Future<bool> _adminCheck;

  @override
  void initState() {
    super.initState();
    _adminCheck = _checkAdminRole();
  }

  Future<bool> _checkAdminRole() async {
    if (!loggedIn || currentUserUid.isEmpty) {
      return false;
    }

    final rows = await UserTable().querySingleRow(
      queryFn: (query) => query.eq('id', currentUserUid),
    );
    if (rows.isEmpty) {
      return false;
    }

    final user = rows.first;
    return user.admin == true || user.adminBurkina == true;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<bool>(
      future: _adminCheck,
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        if (snapshot.data != true) {
          return Scaffold(
            appBar: AppBar(title: const Text('Accès refusé')),
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.lock_outline, size: 48),
                    const SizedBox(height: 16),
                    const Text(
                      'Cette section est réservée aux administrateurs.',
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () => context.go('/'),
                      child: const Text('Retour à l’accueil'),
                    ),
                  ],
                ),
              ),
            ),
          );
        }

        return widget.child;
      },
    );
  }
}