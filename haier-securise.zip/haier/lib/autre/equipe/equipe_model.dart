import '/auth/supabase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/navbar/navbar3/navbar3_widget.dart';
import '/notifications/copie/copie_widget.dart';
import '/notifications/vide/vide_widget.dart';
import 'dart:ui';
import 'equipe_widget.dart' show EquipeWidget;
import 'package:styled_divider/styled_divider.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EquipeModel extends FlutterFlowModel<EquipeWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Navbar3 component.
  late Navbar3Model navbar3Model;

  @override
  void initState(BuildContext context) {
    navbar3Model = createModel(context, () => Navbar3Model());
  }

  @override
  void dispose() {
    navbar3Model.dispose();
  }
}
