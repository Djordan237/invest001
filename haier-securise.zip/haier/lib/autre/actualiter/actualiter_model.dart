import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/navbar/navbar5/navbar5_widget.dart';
import '/notifications/vide/vide_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'actualiter_widget.dart' show ActualiterWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ActualiterModel extends FlutterFlowModel<ActualiterWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Navbar5 component.
  late Navbar5Model navbar5Model;

  @override
  void initState(BuildContext context) {
    navbar5Model = createModel(context, () => Navbar5Model());
  }

  @override
  void dispose() {
    navbar5Model.dispose();
  }
}
