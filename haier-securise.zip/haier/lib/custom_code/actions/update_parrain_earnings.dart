// Automatic FlutterFlow imports
import '/flutter_flow/ff_builtin_enums.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:supabase_flutter/supabase_flutter.dart';

Future<void> updateParrainEarnings(String userId, double amount) async {
  final supabase = Supabase.instance.client;

  try {
    // 1️⃣ Récupérer le code du parrain de l'utilisateur
    final userResponse = await supabase
        .from('user')
        .select('code_parrain')
        .eq('id', userId)
        .maybeSingle();

    if (userResponse == null || userResponse['code_parrain'] == null) {
      print("Aucun parrain trouvé pour cet utilisateur.");
      return;
    }

    String? parrainLv1 = userResponse['code_parrain'];

    if (parrainLv1 != null) {
      // 2️⃣ Récupérer l'ID du parrain de niveau 1
      final parrain1Response = await supabase
          .from('user')
          .select('id, code_parrain, solde, benef_lv1, TT_benefice')
          .eq('code_invitation', parrainLv1)
          .maybeSingle();

      if (parrain1Response != null) {
        String parrainId1 = parrain1Response['id'];
        String? parrainLv2 = parrain1Response['code_parrain'];
        double benefice1 = amount * 0.25;

        // 🔄 Mettre à jour le parrain de niveau 1
        await supabase.from('user').update({
          'solde': (parrain1Response['solde'] ?? 0) + benefice1,
          'benef_lv1': (parrain1Response['benef_lv1'] ?? 0) + benefice1,
          'TT_benefice': (parrain1Response['TT_benefice'] ?? 0) + benefice1,
        }).eq('id', parrainId1);

        if (parrainLv2 != null) {
          // 3️⃣ Récupérer l'ID du parrain de niveau 2
          final parrain2Response = await supabase
              .from('user')
              .select('id, code_parrain, solde, benef_lv2, TT_benefice')
              .eq('code_invitation', parrainLv2)
              .maybeSingle();

          if (parrain2Response != null) {
            String parrainId2 = parrain2Response['id'];
            String? parrainLv3 = parrain2Response['code_parrain'];
            double benefice2 = amount * 0.03;

            // 🔄 Mettre à jour le parrain de niveau 2
            await supabase.from('user').update({
              'solde': (parrain2Response['solde'] ?? 0) + benefice2,
              'benef_lv2': (parrain2Response['benef_lv2'] ?? 0) + benefice2,
              'TT_benefice': (parrain2Response['TT_benefice'] ?? 0) + benefice2,
            }).eq('id', parrainId2);

            if (parrainLv3 != null) {
              // 4️⃣ Récupérer l'ID du parrain de niveau 3
              final parrain3Response = await supabase
                  .from('user')
                  .select('id, solde, benef_lv3, TT_benefice')
                  .eq('code_invitation', parrainLv3)
                  .maybeSingle();

              if (parrain3Response != null) {
                String parrainId3 = parrain3Response['id'];
                double benefice3 = amount * 0.02;

                // 🔄 Mettre à jour le parrain de niveau 3
                await supabase.from('user').update({
                  'solde': (parrain3Response['solde'] ?? 0) + benefice3,
                  'benef_lv3': (parrain3Response['benef_lv3'] ?? 0) + benefice3,
                  'TT_benefice':
                      (parrain3Response['TT_benefice'] ?? 0) + benefice3,
                }).eq('id', parrainId3);
              }
            }
          }
        }
      }
    }
  } catch (error) {
    print("Erreur lors de la mise à jour des gains du parrain: $error");
  }
}
