// Automatic FlutterFlow imports
import '/flutter_flow/ff_builtin_enums.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:supabase_flutter/supabase_flutter.dart';

Future<void> updateParrainBCB(String codeParrain) async {
  if (codeParrain.isEmpty) return;

  final supabase = Supabase.instance.client;

  try {
    print("🔍 Recherche du parrain pour le code : $codeParrain");

    // 1️⃣ Récupérer le parrain direct (LV1)
    final response = await supabase
        .from('user')
        .select('id, code_parrain, uv_LV1, TT_parrainage')
        .eq('code_invitation', codeParrain)
        .maybeSingle();

    if (response == null) {
      print("⚠️ Aucun parrain trouvé.");
      return;
    }

    final parrainId = response['id'];
    final uv_LV1 = response['uv_LV1'] ?? 0;
    final TT_parrainage = response['TT_parrainage'] ?? 0;
    final codeParrainLV2 = response['code_parrain']; // Parrain du parrain (LV2)

    // 🔄 Mise à jour du parrain direct (LV1)
    await supabase.from('user').update({
      'uv_LV1': uv_LV1 + 1,
      'TT_parrainage': TT_parrainage + 1,
    }).eq('id', parrainId);
    print("✅ Mise à jour du parrain LV1 : $parrainId");

    // 2️⃣ Vérifier et mettre à jour le parrain du parrain (LV2)
    if (codeParrainLV2 != null) {
      final responseLV2 = await supabase
          .from('user')
          .select('id, code_parrain, uv_LV2')
          .eq('code_invitation', codeParrainLV2)
          .maybeSingle();

      if (responseLV2 != null) {
        final parrainLV2Id = responseLV2['id'];
        final uv_LV2 = responseLV2['uv_LV2'] ?? 0;
        final codeParrainLV3 =
            responseLV2['code_parrain']; // Parrain du parrain du parrain (LV3)

        await supabase.from('user').update({
          'uv_LV2': uv_LV2 + 1,
        }).eq('id', parrainLV2Id);
        print("✅ Mise à jour du parrain LV2 : $parrainLV2Id");

        // 3️⃣ Vérifier et mettre à jour le parrain du parrain du parrain (LV3)
        if (codeParrainLV3 != null) {
          final responseLV3 = await supabase
              .from('user')
              .select('id, uv_LV3')
              .eq('code_invitation', codeParrainLV3)
              .maybeSingle();

          if (responseLV3 != null) {
            final parrainLV3Id = responseLV3['id'];
            final uv_LV3 = responseLV3['uv_LV3'] ?? 0;

            await supabase.from('user').update({
              'uv_LV3': uv_LV3 + 1,
            }).eq('id', parrainLV3Id);
            print("✅ Mise à jour du parrain LV3 : $parrainLV3Id");
          }
        }
      }
    }
  } catch (error) {
    print("❌ Erreur lors de la mise à jour des parrainages : $error");
  }
}
