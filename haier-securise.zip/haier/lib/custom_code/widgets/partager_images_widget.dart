// Automatic FlutterFlow imports
import '/flutter_flow/ff_builtin_enums.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import '/custom_code/widgets/index.dart';
import '/custom_code/actions/index.dart';
import '/flutter_flow/custom_functions.dart';

import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'dart:typed_data';

class PartagerImagesWidget extends StatefulWidget {
  const PartagerImagesWidget({
    super.key,
    this.width,
    this.height,
    required this.userId,
    required this.bucketName,
    this.onSuccess,
  });

  final double? width;
  final double? height;
  final String userId;

  /// Nom du bucket Supabase Storage (ex : "partager")
  final String bucketName;

  /// Action déclenchée après insertion réussie
  final Future Function()? onSuccess;

  @override
  State<PartagerImagesWidget> createState() => _PartagerImagesWidgetState();
}

class _PartagerImagesWidgetState extends State<PartagerImagesWidget> {
  // ─── État ────────────────────────────────────────────────────
  File? _file1;
  File? _file2;
  bool _isLoading = false;
  String? _errorMessage;
  bool _isDone = false;

  final ImagePicker _picker = ImagePicker();

  // ─── Sélection image ─────────────────────────────────────────
  Future<void> _pickImage(int slot) async {
    try {
      final XFile? picked = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
        maxWidth: 1200,
      );
      if (picked == null) return;
      setState(() {
        if (slot == 1) {
          _file1 = File(picked.path);
        } else {
          _file2 = File(picked.path);
        }
        _errorMessage = null;
      });
    } catch (e) {
      setState(() => _errorMessage = 'Erreur sélection : $e');
    }
  }

  // ─── Upload vers Supabase Storage ────────────────────────────
  Future<String> _uploadFile(File file, int slot) async {
    final Uint8List bytes = await file.readAsBytes();
    final String ext = file.path.split('.').last.toLowerCase();
    final String fileName =
        '${widget.userId}_${DateTime.now().millisecondsSinceEpoch}_img$slot.$ext';
    final String storagePath = 'uploads/$fileName';

    await SupaFlow.client.storage.from(widget.bucketName).uploadBinary(
          storagePath,
          bytes,
          fileOptions: FileOptions(
            contentType: 'image/$ext',
            upsert: true,
          ),
        );

    // Récupère l'URL publique
    final String publicUrl = SupaFlow.client.storage
        .from(widget.bucketName)
        .getPublicUrl(storagePath);

    return publicUrl;
  }

  // ─── Envoi + insertion BDD ────────────────────────────────────
  Future<void> _submit() async {
    if (_file1 == null || _file2 == null) {
      setState(() => _errorMessage = 'Veuillez sélectionner les 2 images.');
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });

    try {
      // 1. Upload des deux images en parallèle
      final results = await Future.wait([
        _uploadFile(_file1!, 1),
        _uploadFile(_file2!, 2),
      ]);

      final String url1 = results[0];
      final String url2 = results[1];

      // 2. Insertion dans the table used by FlutterFlow/Supabase.
      await SupaFlow.client.from('partage_user').insert({
        'userId': widget.userId,
        'image1': url1,
        'image2': url2,
      });

      setState(() {
        _isDone = true;
        _isLoading = false;
      });

      // 3. Callback FlutterFlow
      if (widget.onSuccess != null) {
        await widget.onSuccess!();
      }
    } catch (e) {
      setState(() {
        _errorMessage = 'Erreur : $e';
        _isLoading = false;
      });
    }
  }

  // ─── Reset ───────────────────────────────────────────────────
  void _reset() {
    setState(() {
      _file1 = null;
      _file2 = null;
      _isDone = false;
      _errorMessage = null;
    });
  }

  // ─── Build ───────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.width,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0D1B3E),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── Titre ─────────────────────────────────────────
          const Text(
            'Partager vos images',
            style: TextStyle(
              color: Colors.white,
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),

          // ── Succès ────────────────────────────────────────
          if (_isDone) ...[
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF1A3A1A),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.greenAccent, width: 1),
              ),
              child: Column(
                children: [
                  const Icon(Icons.check_circle_rounded,
                      color: Colors.greenAccent, size: 40),
                  const SizedBox(height: 8),
                  const Text(
                    'Images partagées avec succès !',
                    style: TextStyle(color: Colors.greenAccent, fontSize: 14),
                  ),
                  const SizedBox(height: 12),
                  TextButton(
                    onPressed: _reset,
                    child: const Text(
                      'Partager à nouveau',
                      style: TextStyle(color: Colors.white70, fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),
          ] else ...[
            // ── Slots images ──────────────────────────────
            Row(
              children: [
                Expanded(child: _buildSlot(1, _file1)),
                const SizedBox(width: 12),
                Expanded(child: _buildSlot(2, _file2)),
              ],
            ),
            const SizedBox(height: 16),

            // ── Erreur ────────────────────────────────────
            if (_errorMessage != null) ...[
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.redAccent, width: 0.8),
                ),
                child: Text(
                  _errorMessage!,
                  style: const TextStyle(color: Colors.redAccent, fontSize: 12),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 12),
            ],

            // ── Bouton Partager ────────────────────────────
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: (_isLoading) ? null : _submit,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2979FF),
                  disabledBackgroundColor: Colors.blueGrey,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: _isLoading
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          valueColor: AlwaysStoppedAnimation(Colors.white),
                        ),
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: const [
                          Icon(Icons.cloud_upload_rounded,
                              color: Colors.white, size: 18),
                          SizedBox(width: 8),
                          Text(
                            'Partager',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                            ),
                          ),
                        ],
                      ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ─── Slot image ──────────────────────────────────────────────
  Widget _buildSlot(int slot, File? file) {
    return GestureDetector(
      onTap: _isLoading ? null : () => _pickImage(slot),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 150,
        decoration: BoxDecoration(
          color: const Color(0xFF1A2744),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: file != null ? const Color(0xFF2979FF) : Colors.white24,
            width: file != null ? 2 : 1,
          ),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(13),
          child: file != null
              // ── Aperçu de l'image choisie ────────────
              ? Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.file(file, fit: BoxFit.cover),
                    // Bouton changer
                    Positioned(
                      bottom: 6,
                      right: 6,
                      child: Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.edit_rounded,
                            color: Colors.white, size: 14),
                      ),
                    ),
                  ],
                )
              // ── Placeholder vide ─────────────────────
              : Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.add_photo_alternate_rounded,
                      color: Colors.white38,
                      size: 36,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Image $slot',
                      style: const TextStyle(
                        color: Colors.white38,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}
