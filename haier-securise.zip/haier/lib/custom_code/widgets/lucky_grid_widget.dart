// Automatic FlutterFlow imports
import '/flutter_flow/ff_builtin_enums.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// ============================================================
// LUCKY GRID WIDGET — FlutterFlow Custom Widget v3
// ============================================================
// Paramètres à déclarer dans FlutterFlow :
//
//   • width   : double   (optionnel)
//   • height  : double   (optionnel)
//   • solde   : double   (requis) — solde du joueur en points
//                         Si solde < 1 → affiche "Points insuffisants"
//   • onWin   : Action   (requis)
//               Argument de sortie : prizeName (String)
//               → déclenché uniquement pour les lots monétaires
//
// ── Probabilités ────────────────────────────────────────────
//     200 LE        →  45 %
//     5 000 LE      →  28 %
//     20 000 LE     →  20 %
//     1 000 000 LE  →   5 %
//     2 000 000 LE  →   2 %
//   BMW X5 / iPhone / Yamaha → 0 % (décor uniquement)
// ============================================================

import '/custom_code/widgets/index.dart';
import '/flutter_flow/custom_functions.dart';

import 'dart:async';
import 'dart:math';

class LuckyGridWidget extends StatefulWidget {
  const LuckyGridWidget({
    super.key,
    this.width,
    this.height,
    required this.solde,
    required this.onWin,
  });

  final double? width;
  final double? height;

  /// Solde du joueur en points. Le jeu est verrouillé si solde < 1.
  final double solde;

  /// Action FlutterFlow déclenchée après un spin gagnant (lot monétaire).
  /// Reçoit [prizeName] (String) : libellé du lot remporté.
  final Future Function(String prizeName, int prizeAmount) onWin;
  @override
  State<LuckyGridWidget> createState() => _LuckyGridWidgetState();
}

class _LuckyGridWidgetState extends State<LuckyGridWidget>
    with TickerProviderStateMixin {
  // ─── URLs des images des lots physiques ─────────────────────
  static const String _bmwUrl =
      'https://dnlwduauvogmwzkdyzct.supabase.co/storage/v1/object/sign/game/download__21_-removebg-preview.png?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV82MTc1N2VmMS0yMTQ3LTQ3M2EtYmQzZS0zMGEyNWIzZDk0NzgiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJnYW1lL2Rvd25sb2FkX18yMV8tcmVtb3ZlYmctcHJldmlldy5wbmciLCJpYXQiOjE3NzgzNjQ5MjcsImV4cCI6MTgwOTkwMDkyN30.QhkKH9bBgKXWHFmlMMKR5nqS1uBSNhjBpINqQnJJl1s';

  static const String _iphoneUrl =
      'https://dnlwduauvogmwzkdyzct.supabase.co/storage/v1/object/sign/game/iPhone_16_Pro-removebg-preview.png?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV82MTc1N2VmMS0yMTQ3LTQ3M2EtYmQzZS0zMGEyNWIzZDk0NzgiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJnYW1lL2lQaG9uZV8xNl9Qcm8tcmVtb3ZlYmctcHJldmlldy5wbmciLCJpYXQiOjE3NzgzNjUxMzYsImV4cCI6MTgwOTkwMTEzNn0.pKaMtcwXxL3D_imkG5mLaJCXfc6bQTUfl6zwZeuzmwU';

  static const String _yamahaUrl =
      'https://dnlwduauvogmwzkdyzct.supabase.co/storage/v1/object/sign/game/Yamaha_Scooty_Price_List_in_India-removebg-preview.png?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV82MTc1N2VmMS0yMTQ3LTQ3M2EtYmQzZS0zMGEyNWIzZDk0NzgiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJnYW1lL1lhbWFoYV9TY29vdHlfUHJpY2VfTGlzdF9pbl9JbmRpYS1yZW1vdmViZy1wcmV2aWV3LnBuZyIsImlhdCI6MTc3ODM2NTE2MiwiZXhwIjoxODA5OTAxMTYyfQ.i3u2He298wR834fKKTelvaH1dKZCHepK9CcJIsHC_o8';

  // ─── Données des cases ──────────────────────────────────────
  static final List<_Prize> _prizes = [
    _Prize(index: 0, label: '500 CFA', type: PrizeType.money, weight: 70),
    _Prize(
        index: 1,
        label: 'BMW X5',
        type: PrizeType.physical,
        weight: 0,
        imageUrl: _bmwUrl),
    _Prize(index: 2, label: '20 000 CFA', type: PrizeType.money, weight: 7),
    _Prize(index: 3, label: '100 000 CFA', type: PrizeType.money, weight: 0),
    _Prize(index: 4, label: 'GO', type: PrizeType.go, weight: 0),
    _Prize(
        index: 5,
        label: 'iPhone 16 PM',
        type: PrizeType.physical,
        weight: 0,
        imageUrl: _iphoneUrl),
    _Prize(
        index: 6,
        label: 'Yamaha',
        type: PrizeType.physical,
        weight: 0,
        imageUrl: _yamahaUrl),
    _Prize(index: 7, label: '2000 CFA', type: PrizeType.money, weight: 23),
    _Prize(index: 8, label: '200 000 CFA', type: PrizeType.money, weight: 0),
  ];

  static const List<int> _playableIndices = [0, 1, 2, 3, 5, 6, 7, 8];

  // ─── État ───────────────────────────────────────────────────
  int _highlightedIndex = -1;
  int _winnerIndex = -1;
  bool _isSpinning = false;
  bool _hasPlayed = false;

  Timer? _timer;
  late AnimationController _pulseController;
  late Animation<double> _pulseAnim;

  bool get _insufficientBalance => widget.solde < 1;

  // ─── Tirage pondéré ─────────────────────────────────────────
  int _pickWeightedWinner() {
    final monetary = _prizes
        .where((p) => p.type == PrizeType.money && p.weight > 0)
        .toList();
    final total = monetary.fold<int>(0, (s, p) => s + p.weight);
    int roll = Random().nextInt(total) + 1;
    for (final p in monetary) {
      roll -= p.weight;
      if (roll <= 0) return p.index;
    }
    return monetary.last.index;
  }

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 1.0, end: 1.08).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pulseController.dispose();
    super.dispose();
  }

// ─── Extrait le montant entier depuis le libellé ─────────────
// Exemples : "500 CFA" → 500 | "20 000 CFA" → 20000
  int _parseAmount(String label) {
    final digits = label.replaceAll(RegExp(r'[^0-9]'), '');
    return int.tryParse(digits) ?? 0;
  }

  // ─── Spin ───────────────────────────────────────────────────
  void _startSpin() {
    if (_isSpinning || _hasPlayed || _insufficientBalance) return;

    final winnerIdx = _pickWeightedWinner();
    final totalSteps = 24 + Random().nextInt(8);
    int step = 0, currentPos = 0;

    setState(() {
      _isSpinning = true;
      _winnerIndex = -1;
      _highlightedIndex = -1;
    });

    void tick() {
      if (step >= totalSteps) {
        while (_playableIndices[currentPos % _playableIndices.length] !=
            winnerIdx) {
          currentPos++;
        }
        setState(() {
          _highlightedIndex = winnerIdx;
          _winnerIndex = winnerIdx;
          _isSpinning = false;
          _hasPlayed = true;
        });
        widget.onWin(
          _prizes[winnerIdx].label,
          _parseAmount(_prizes[winnerIdx].label),
        );
        return;
      }
      final progress = step / totalSteps;
      final delayMs = progress < 0.35
          ? 60
          : progress < 0.70
              ? 130
              : 280;
      setState(() {
        _highlightedIndex =
            _playableIndices[currentPos % _playableIndices.length];
      });
      currentPos++;
      step++;
      _timer = Timer(Duration(milliseconds: delayMs), tick);
    }

    tick();
  }

  void _reset() {
    _timer?.cancel();
    setState(() {
      _highlightedIndex = -1;
      _winnerIndex = -1;
      _isSpinning = false;
      _hasPlayed = false;
    });
  }

  // ─── Build ──────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.width,
      height: widget.height,
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF7DD8F8), Color(0xFF4A8FE8)],
        ),
        borderRadius: BorderRadius.circular(24),
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── Header ─────────────────────────────────────────
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(children: [
                  const Icon(Icons.toll_rounded, color: Colors.white, size: 14),
                  const SizedBox(width: 4),
                  Text(
                    '${widget.solde.toStringAsFixed(0)} pts',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold),
                  ),
                ]),
              ),
              GestureDetector(
                onTap: _reset,
                child: const Text(
                  'Mes récompenses  »',
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 12),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // ── Grille ─────────────────────────────────────────
          AspectRatio(
            aspectRatio: 1,
            child: Stack(children: [
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                ),
                itemCount: 9,
                itemBuilder: (_, i) => _buildTile(_prizes[i]),
              ),

              // ── Overlay solde insuffisant ───────────────
              if (_insufficientBalance)
                Positioned.fill(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: Container(
                      color: Colors.black.withOpacity(0.55),
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 18, vertical: 12),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: const [
                              Icon(Icons.lock_rounded,
                                  color: Color(0xFFE53935), size: 30),
                              SizedBox(height: 6),
                              Text(
                                'Points insuffisants',
                                style: TextStyle(
                                  color: Color(0xFFE53935),
                                  fontWeight: FontWeight.w800,
                                  fontSize: 14,
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                'Minimum requis : 1 point',
                                style: TextStyle(
                                    color: Color(0xFF888888), fontSize: 11),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
            ]),
          ),

          // ── Résultat ───────────────────────────────────────
          if (_hasPlayed) ...[
            const SizedBox(height: 12),
            AnimatedOpacity(
              opacity: 1,
              duration: const Duration(milliseconds: 500),
              child: Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '🎉  Vous avez gagné : ${_prizes[_winnerIndex].label}',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1565C0),
                    fontSize: 13,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ─── Tuile ──────────────────────────────────────────────────
  Widget _buildTile(_Prize prize) {
    final isGo = prize.type == PrizeType.go;
    final isHighlighted = _highlightedIndex == prize.index;
    final isWinner = _winnerIndex == prize.index;
    final isPhysical = prize.type == PrizeType.physical;

    // ── Centre GO ─────────────────────────────────────────
    if (isGo) {
      return GestureDetector(
        onTap: _startSpin,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          decoration: BoxDecoration(
            color: _isSpinning ? const Color(0xFFBBDEFB) : Colors.white,
            borderRadius: BorderRadius.circular(14),
            boxShadow: const [
              BoxShadow(
                  color: Colors.black26, blurRadius: 6, offset: Offset(0, 3)),
            ],
          ),
          child: Center(
            child: _isSpinning
                ? const CircularProgressIndicator(
                    strokeWidth: 3,
                    valueColor: AlwaysStoppedAnimation(Color(0xFF1565C0)),
                  )
                : Text(
                    _hasPlayed ? '↺' : 'GO',
                    style: TextStyle(
                      fontSize: _hasPlayed ? 30 : 28,
                      fontWeight: FontWeight.w900,
                      color: _insufficientBalance && !_hasPlayed
                          ? const Color(0xFFBBBBBB)
                          : const Color(0xFF1565C0),
                    ),
                  ),
          ),
        ),
      );
    }

    // ── Couleur de fond ────────────────────────────────────
    final Color bgColor = isWinner
        ? const Color(0xFFFFD600)
        : isHighlighted
            ? const Color(0xFF90CAF9)
            : isPhysical
                ? const Color(0xFF2D6FBB)
                : const Color(0xFF3A80D5);

    Widget tile = AnimatedContainer(
      duration: const Duration(milliseconds: 80),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(14),
        boxShadow: (isWinner || isHighlighted)
            ? [
                BoxShadow(
                  color: Colors.yellowAccent.withOpacity(0.7),
                  blurRadius: 12,
                  spreadRadius: 2,
                )
              ]
            : const [
                BoxShadow(
                    color: Colors.black26, blurRadius: 4, offset: Offset(0, 2))
              ],
      ),
      child: Stack(children: [
        // Contenu principal
        Padding(
          padding: const EdgeInsets.all(4),
          child: Center(child: _buildContent(prize, isWinner, isHighlighted)),
        ),
        // Badge "Expo" sur les lots physiques au repos
        if (isPhysical && !isHighlighted && !isWinner)
          Positioned(
            top: 4,
            right: 4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.25),
                borderRadius: BorderRadius.circular(4),
              ),
              child: const Text(
                'Extra🔥',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 8,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ),
      ]),
    );

    return isWinner ? ScaleTransition(scale: _pulseAnim, child: tile) : tile;
  }

  // ─── Contenu ────────────────────────────────────────────────
  Widget _buildContent(_Prize prize, bool isWinner, bool isHighlighted) {
    switch (prize.type) {
      // ── Lots physiques : image réseau ──────────────────
      case PrizeType.physical:
        return Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Image.network(
                  prize.imageUrl!,
                  fit: BoxFit.contain,
                  // Affiche un loader pendant le chargement
                  loadingBuilder: (_, child, progress) {
                    if (progress == null) return child;
                    return const Center(
                      child: SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation(Colors.white54),
                        ),
                      ),
                    );
                  },
                  // Icône fallback si l'image ne charge pas
                  errorBuilder: (_, __, ___) => Icon(
                    prize.label == 'BMW X5'
                        ? Icons.directions_car_filled
                        : prize.label == 'Yamaha'
                            ? Icons.two_wheeler
                            : Icons.phone_iphone,
                    color: Colors.white,
                    size: 28,
                  ),
                ),
              ),
            ),
            // Nom affiché seulement si la case est active (highlight ou winner)
            if (isWinner || isHighlighted)
              Text(
                prize.label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                ),
                textAlign: TextAlign.center,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
          ],
        );

      // ── Lots monétaires : texte ────────────────────────
      case PrizeType.money:
        return FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            prize.label,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w800,
              fontSize: 18,
            ),
            textAlign: TextAlign.center,
          ),
        );

      default:
        return const SizedBox();
    }
  }
}

// ─── Modèles internes ───────────────────────────────────────────
enum PrizeType { money, physical, go }

class _Prize {
  const _Prize({
    required this.index,
    required this.label,
    required this.type,
    required this.weight,
    this.imageUrl,
  });

  final int index;
  final String label;
  final PrizeType type;

  /// Poids de probabilité (0 = jamais gagnable).
  final int weight;

  /// URL de l'image (uniquement pour PrizeType.physical).
  final String? imageUrl;
}
// Set your widget name, define your parameter, and then add the
// boilerplate code using the green button on the right!
