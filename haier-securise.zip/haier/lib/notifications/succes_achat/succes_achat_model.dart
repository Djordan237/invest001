import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'succes_achat_widget.dart' show SuccesAchatWidget;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SuccesAchatModel extends FlutterFlowModel<SuccesAchatWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
