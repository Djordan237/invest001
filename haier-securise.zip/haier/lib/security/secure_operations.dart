import '/backend/supabase/supabase.dart';

/// All balance-changing operations must go through these database functions.
/// The database validates the authenticated user, locks the balance row, and
/// commits the balance and ledger changes in one transaction.
class SecureOperations {
  SecureOperations._();

  static Future<Map<String, dynamic>> purchaseProduct({
    required int productId,
  }) async {
    final result = await SupaFlow.client.rpc(
      'purchase_product',
      params: {'p_product_id': productId},
    );
    return Map<String, dynamic>.from(result as Map);
  }

  static Future<Map<String, dynamic>> requestWithdrawal({
    required double amount,
    required String address,
    required String method,
    required String userName,
  }) async {
    final result = await SupaFlow.client.rpc(
      'request_withdrawal',
      params: {
        'p_amount': amount,
        'p_address': address,
        'p_method': method,
        'p_user_name': userName,
      },
    );
    return Map<String, dynamic>.from(result as Map);
  }

  static Future<Map<String, dynamic>> claimLotteryPrize({
    required String prizeName,
  }) async {
    final result = await SupaFlow.client.rpc(
      'claim_lottery_prize',
      params: {'p_prize_name': prizeName},
    );
    return Map<String, dynamic>.from(result as Map);
  }

  static Future<Map<String, dynamic>> redeemBonusCode({
    required String code,
  }) async {
    final result = await SupaFlow.client.rpc(
      'redeem_bonus_code',
      params: {'p_code': code.trim()},
    );
    return Map<String, dynamic>.from(result as Map);
  }

  static Future<Map<String, dynamic>> collectProductRevenue({
    required int productUserNumber,
  }) async {
    final result = await SupaFlow.client.rpc(
      'collect_product_revenue',
      params: {'p_product_user_num': productUserNumber},
    );
    return Map<String, dynamic>.from(result as Map);
  }
}