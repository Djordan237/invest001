import '../database.dart';

class ProduitUserTable extends SupabaseTable<ProduitUserRow> {
  @override
  String get tableName => 'produit_user';

  @override
  ProduitUserRow createRow(Map<String, dynamic> data) => ProduitUserRow(data);
}

class ProduitUserRow extends SupabaseDataRow {
  ProduitUserRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ProduitUserTable();

  int get num => getField<int>('num')!;
  set num(int value) => setField<int>('num', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String? get id => getField<String>('id');
  set id(String? value) => setField<String>('id', value);

  String? get nom => getField<String>('nom');
  set nom(String? value) => setField<String>('nom', value);

  int? get cycle => getField<int>('cycle');
  set cycle(int? value) => setField<int>('cycle', value);

  int? get revenuJour => getField<int>('revenu_jour');
  set revenuJour(int? value) => setField<int>('revenu_jour', value);

  int? get totalRecu => getField<int>('total_recu');
  set totalRecu(int? value) => setField<int>('total_recu', value);

  int? get totalGains => getField<int>('total_gains');
  set totalGains(int? value) => setField<int>('total_gains', value);

  int? get prix => getField<int>('prix');
  set prix(int? value) => setField<int>('prix', value);

  String? get taux => getField<String>('taux');
  set taux(String? value) => setField<String>('taux', value);

  String? get image => getField<String>('image');
  set image(String? value) => setField<String>('image', value);

  bool? get collecte => getField<bool>('collecte');
  set collecte(bool? value) => setField<bool>('collecte', value);
}
