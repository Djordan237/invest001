import '../database.dart';

class NumeroTable extends SupabaseTable<NumeroRow> {
  @override
  String get tableName => 'numero';

  @override
  NumeroRow createRow(Map<String, dynamic> data) => NumeroRow(data);
}

class NumeroRow extends SupabaseDataRow {
  NumeroRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => NumeroTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String? get nom => getField<String>('nom');
  set nom(String? value) => setField<String>('nom', value);

  String? get numero => getField<String>('numéro');
  set numero(String? value) => setField<String>('numéro', value);

  String? get nomCarte => getField<String>('nom_carte');
  set nomCarte(String? value) => setField<String>('nom_carte', value);
}
