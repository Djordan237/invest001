import '../database.dart';

class MethodeTransactionTable extends SupabaseTable<MethodeTransactionRow> {
  @override
  String get tableName => 'methode_transaction';

  @override
  MethodeTransactionRow createRow(Map<String, dynamic> data) =>
      MethodeTransactionRow(data);
}

class MethodeTransactionRow extends SupabaseDataRow {
  MethodeTransactionRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => MethodeTransactionTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String? get image => getField<String>('image');
  set image(String? value) => setField<String>('image', value);

  String? get nom => getField<String>('nom');
  set nom(String? value) => setField<String>('nom', value);

  bool? get disponibilite => getField<bool>('disponibilite');
  set disponibilite(bool? value) => setField<bool>('disponibilite', value);

  String? get url => getField<String>('url');
  set url(String? value) => setField<String>('url', value);

  String? get numero => getField<String>('numéro');
  set numero(String? value) => setField<String>('numéro', value);

  String? get nomCarte => getField<String>('nom_carte');
  set nomCarte(String? value) => setField<String>('nom_carte', value);
}
