import '../database.dart';

class RobotUserTable extends SupabaseTable<RobotUserRow> {
  @override
  String get tableName => 'robot_user';

  @override
  RobotUserRow createRow(Map<String, dynamic> data) => RobotUserRow(data);
}

class RobotUserRow extends SupabaseDataRow {
  RobotUserRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => RobotUserTable();

  int get num => getField<int>('num')!;
  set num(int value) => setField<int>('num', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String? get id => getField<String>('id');
  set id(String? value) => setField<String>('id', value);

  double? get montant => getField<double>('montant');
  set montant(double? value) => setField<double>('montant', value);

  int? get cycle => getField<int>('cycle');
  set cycle(int? value) => setField<int>('cycle', value);

  double? get profitFinal => getField<double>('profit_final');
  set profitFinal(double? value) => setField<double>('profit_final', value);

  double? get profitJour => getField<double>('profit_jour');
  set profitJour(double? value) => setField<double>('profit_jour', value);
}
