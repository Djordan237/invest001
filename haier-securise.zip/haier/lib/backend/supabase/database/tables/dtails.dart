import '../database.dart';

class DtailsTable extends SupabaseTable<DtailsRow> {
  @override
  String get tableName => 'détails';

  @override
  DtailsRow createRow(Map<String, dynamic> data) => DtailsRow(data);
}

class DtailsRow extends SupabaseDataRow {
  DtailsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => DtailsTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  int? get bonusInscription => getField<int>('bonus_inscription');
  set bonusInscription(int? value) => setField<int>('bonus_inscription', value);

  double? get fraisRetrait => getField<double>('frais_retrait');
  set fraisRetrait(double? value) => setField<double>('frais_retrait', value);
}
