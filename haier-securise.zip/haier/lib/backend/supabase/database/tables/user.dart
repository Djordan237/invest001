import '../database.dart';

class UserTable extends SupabaseTable<UserRow> {
  @override
  String get tableName => 'user';

  @override
  UserRow createRow(Map<String, dynamic> data) => UserRow(data);
}

class UserRow extends SupabaseDataRow {
  UserRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => UserTable();

  int get num => getField<int>('num')!;
  set num(int value) => setField<int>('num', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String? get email => getField<String>('email');
  set email(String? value) => setField<String>('email', value);

  String? get codeInvitation => getField<String>('code_invitation');
  set codeInvitation(String? value) =>
      setField<String>('code_invitation', value);

  String? get codeParrain => getField<String>('code_parrain');
  set codeParrain(String? value) => setField<String>('code_parrain', value);

  double? get solde => getField<double>('solde');
  set solde(double? value) => setField<double>('solde', value);

  double? get gainsJour => getField<double>('gains_jour');
  set gainsJour(double? value) => setField<double>('gains_jour', value);

  double? get soldeRobot => getField<double>('solde_robot');
  set soldeRobot(double? value) => setField<double>('solde_robot', value);

  double? get revenuRobot => getField<double>('revenu_robot');
  set revenuRobot(double? value) => setField<double>('revenu_robot', value);

  double? get ttRecharge => getField<double>('tt_recharge');
  set ttRecharge(double? value) => setField<double>('tt_recharge', value);

  double? get salaireEquipe => getField<double>('salaire_equipe');
  set salaireEquipe(double? value) => setField<double>('salaire_equipe', value);

  double? get ttGains => getField<double>('tt_gains');
  set ttGains(double? value) => setField<double>('tt_gains', value);

  double? get ttRetraits => getField<double>('tt_retraits');
  set ttRetraits(double? value) => setField<double>('tt_retraits', value);

  String? get identifiant => getField<String>('identifiant');
  set identifiant(String? value) => setField<String>('identifiant', value);

  int? get TTparrainage => getField<int>('TT_parrainage');
  set TTparrainage(int? value) => setField<int>('TT_parrainage', value);

  double? get tTBenefice => getField<double>('TT_benefice');
  set tTBenefice(double? value) => setField<double>('TT_benefice', value);

  int? get ttProduits => getField<int>('tt_produits');
  set ttProduits(int? value) => setField<int>('tt_produits', value);

  String? get pays => getField<String>('pays');
  set pays(String? value) => setField<String>('pays', value);

  bool? get retraitVisible => getField<bool>('retrait_visible');
  set retraitVisible(bool? value) => setField<bool>('retrait_visible', value);

  bool? get bonusActif => getField<bool>('bonus_actif');
  set bonusActif(bool? value) => setField<bool>('bonus_actif', value);

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  int? get uvLV2 => getField<int>('uv_LV2');
  set uvLV2(int? value) => setField<int>('uv_LV2', value);

  int? get uvLV3 => getField<int>('uv_LV3');
  set uvLV3(int? value) => setField<int>('uv_LV3', value);

  int? get telephone => getField<int>('telephone');
  set telephone(int? value) => setField<int>('telephone', value);

  String? get parrainId => getField<String>('parrain_id');
  set parrainId(String? value) => setField<String>('parrain_id', value);

  double? get point => getField<double>('point');
  set point(double? value) => setField<double>('point', value);

  double? get benefLv1 => getField<double>('benef_lv1');
  set benefLv1(double? value) => setField<double>('benef_lv1', value);

  double? get benefLv2 => getField<double>('benef_lv2');
  set benefLv2(double? value) => setField<double>('benef_lv2', value);

  double? get benefLv3 => getField<double>('benef_lv3');
  set benefLv3(double? value) => setField<double>('benef_lv3', value);

  int? get uvLV1 => getField<int>('uv_LV1');
  set uvLV1(int? value) => setField<int>('uv_LV1', value);

  int? get uvlv1 => getField<int>('uv_lv1');
  set uvlv1(int? value) => setField<int>('uv_lv1', value);

  int? get uvlv2 => getField<int>('uv_lv2');
  set uvlv2(int? value) => setField<int>('uv_lv2', value);

  int? get uvlv3 => getField<int>('uv_lv3');
  set uvlv3(int? value) => setField<int>('uv_lv3', value);

  int? get ttparrainage => getField<int>('tt_parrainage');
  set ttparrainage(int? value) => setField<int>('tt_parrainage', value);

  bool? get admin => getField<bool>('admin');
  set admin(bool? value) => setField<bool>('admin', value);

  bool? get adminBurkina => getField<bool>('admin_burkina');
  set adminBurkina(bool? value) => setField<bool>('admin_burkina', value);
}
