import '../database.dart';

class HistoriqueParrainageTable extends SupabaseTable<HistoriqueParrainageRow> {
  @override
  String get tableName => 'historique_parrainage';

  @override
  HistoriqueParrainageRow createRow(Map<String, dynamic> data) =>
      HistoriqueParrainageRow(data);
}

class HistoriqueParrainageRow extends SupabaseDataRow {
  HistoriqueParrainageRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => HistoriqueParrainageTable();

  int? get id => getField<int>('id');
  set id(int? value) => setField<int>('id', value);

  String get parrainId => getField<String>('parrain_id')!;
  set parrainId(String value) => setField<String>('parrain_id', value);

  String get filleulEmail => getField<String>('filleul_email')!;
  set filleulEmail(String value) => setField<String>('filleul_email', value);

  double? get ttRecharge => getField<double>('tt_recharge');
  set ttRecharge(double? value) => setField<double>('tt_recharge', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);
}
