import '../database.dart';

class ParrainageTable extends SupabaseTable<ParrainageRow> {
  @override
  String get tableName => 'parrainage';

  @override
  ParrainageRow createRow(Map<String, dynamic> data) => ParrainageRow(data);
}

class ParrainageRow extends SupabaseDataRow {
  ParrainageRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ParrainageTable();

  int? get id => getField<int>('id');
  set id(int? value) => setField<int>('id', value);

  String get parrainId => getField<String>('parrain_id')!;
  set parrainId(String value) => setField<String>('parrain_id', value);

  String get filleulId => getField<String>('filleul_id')!;
  set filleulId(String value) => setField<String>('filleul_id', value);

  int get niveau => getField<int>('niveau')!;
  set niveau(int value) => setField<int>('niveau', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);
}
