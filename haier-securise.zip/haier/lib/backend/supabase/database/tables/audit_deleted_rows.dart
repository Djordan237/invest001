import '../database.dart';

class AuditDeletedRowsTable extends SupabaseTable<AuditDeletedRowsRow> {
  @override
  String get tableName => 'audit_deleted_rows';

  @override
  AuditDeletedRowsRow createRow(Map<String, dynamic> data) =>
      AuditDeletedRowsRow(data);
}

class AuditDeletedRowsRow extends SupabaseDataRow {
  AuditDeletedRowsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => AuditDeletedRowsTable();

  int? get id => getField<int>('id');
  set id(int? value) => setField<int>('id', value);

  String get tableNameField => getField<String>('table_name')!;
  set tableNameField(String value) => setField<String>('table_name', value);

  DateTime? get deletedAt => getField<DateTime>('deleted_at');
  set deletedAt(DateTime? value) => setField<DateTime>('deleted_at', value);

  String? get deletedBy => getField<String>('deleted_by');
  set deletedBy(String? value) => setField<String>('deleted_by', value);

  dynamic get rowData => getField<dynamic>('row_data')!;
  set rowData(dynamic value) => setField<dynamic>('row_data', value);
}
