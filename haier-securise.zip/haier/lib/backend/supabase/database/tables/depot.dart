import '../database.dart';

class DepotTable extends SupabaseTable<DepotRow> {
  @override
  String get tableName => 'depot';

  @override
  DepotRow createRow(Map<String, dynamic> data) => DepotRow(data);
}

class DepotRow extends SupabaseDataRow {
  DepotRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => DepotTable();

  int get num => getField<int>('num')!;
  set num(int value) => setField<int>('num', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String? get id => getField<String>('id');
  set id(String? value) => setField<String>('id', value);

  double? get montant => getField<double>('montant');
  set montant(double? value) => setField<double>('montant', value);

  String? get reseau => getField<String>('reseau');
  set reseau(String? value) => setField<String>('reseau', value);

  bool? get statutAttente => getField<bool>('statut_attente');
  set statutAttente(bool? value) => setField<bool>('statut_attente', value);

  bool? get statutEchec => getField<bool>('statut_echec');
  set statutEchec(bool? value) => setField<bool>('statut_echec', value);

  String? get idDepot => getField<String>('id_depot');
  set idDepot(String? value) => setField<String>('id_depot', value);

  bool? get statutSucces => getField<bool>('statut_succes');
  set statutSucces(bool? value) => setField<bool>('statut_succes', value);

  String? get capture => getField<String>('capture');
  set capture(String? value) => setField<String>('capture', value);

  String? get numeroPayeur => getField<String>('numero_payeur');
  set numeroPayeur(String? value) => setField<String>('numero_payeur', value);
}
