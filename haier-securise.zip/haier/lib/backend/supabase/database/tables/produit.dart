import '../database.dart';

class ProduitTable extends SupabaseTable<ProduitRow> {
  @override
  String get tableName => 'produit';

  @override
  ProduitRow createRow(Map<String, dynamic> data) => ProduitRow(data);
}

class ProduitRow extends SupabaseDataRow {
  ProduitRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ProduitTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String? get nomProduit => getField<String>('nom_produit');
  set nomProduit(String? value) => setField<String>('nom_produit', value);

  String? get imageProduit => getField<String>('image_produit');
  set imageProduit(String? value) => setField<String>('image_produit', value);

  String? get numeroSerie => getField<String>('numero_serie');
  set numeroSerie(String? value) => setField<String>('numero_serie', value);

  int? get vip => getField<int>('vip');
  set vip(int? value) => setField<int>('vip', value);

  int? get cycle => getField<int>('cycle');
  set cycle(int? value) => setField<int>('cycle', value);

  String? get interet => getField<String>('interet');
  set interet(String? value) => setField<String>('interet', value);

  int? get prix => getField<int>('prix');
  set prix(int? value) => setField<int>('prix', value);

  int? get revenuJour => getField<int>('revenu_jour');
  set revenuJour(int? value) => setField<int>('revenu_jour', value);

  int? get revenuTt => getField<int>('revenu_tt');
  set revenuTt(int? value) => setField<int>('revenu_tt', value);

  String? get detailProduits => getField<String>('detail_produits');
  set detailProduits(String? value) =>
      setField<String>('detail_produits', value);

  double? get points => getField<double>('points');
  set points(double? value) => setField<double>('points', value);
}
