import '../database.dart';

class PartageUserTable extends SupabaseTable<PartageUserRow> {
  @override
  String get tableName => 'partage_user';

  @override
  PartageUserRow createRow(Map<String, dynamic> data) => PartageUserRow(data);
}

class PartageUserRow extends SupabaseDataRow {
  PartageUserRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => PartageUserTable();

  int get num => getField<int>('num')!;
  set num(int value) => setField<int>('num', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String? get numero => getField<String>('numero');
  set numero(String? value) => setField<String>('numero', value);

  String? get message => getField<String>('message');
  set message(String? value) => setField<String>('message', value);

  String? get image1 => getField<String>('image1');
  set image1(String? value) => setField<String>('image1', value);

  String? get image2 => getField<String>('image2');
  set image2(String? value) => setField<String>('image2', value);

  String? get userId => getField<String>('userId');
  set userId(String? value) => setField<String>('userId', value);
}
