import '../database.dart';

class RetraitTable extends SupabaseTable<RetraitRow> {
  @override
  String get tableName => 'retrait';

  @override
  RetraitRow createRow(Map<String, dynamic> data) => RetraitRow(data);
}

class RetraitRow extends SupabaseDataRow {
  RetraitRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => RetraitTable();

  int get num => getField<int>('num')!;
  set num(int value) => setField<int>('num', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String? get id => getField<String>('id');
  set id(String? value) => setField<String>('id', value);

  String? get idRetrait => getField<String>('id_retrait');
  set idRetrait(String? value) => setField<String>('id_retrait', value);

  String? get adresse => getField<String>('adresse');
  set adresse(String? value) => setField<String>('adresse', value);

  double? get montantRetrait => getField<double>('montant_retrait');
  set montantRetrait(double? value) =>
      setField<double>('montant_retrait', value);

  double? get montantRecu => getField<double>('montant_recu');
  set montantRecu(double? value) => setField<double>('montant_recu', value);

  String? get methode => getField<String>('methode');
  set methode(String? value) => setField<String>('methode', value);

  bool? get statutAttente => getField<bool>('statut_attente');
  set statutAttente(bool? value) => setField<bool>('statut_attente', value);

  bool? get statutSucces => getField<bool>('statut_succès');
  set statutSucces(bool? value) => setField<bool>('statut_succès', value);

  bool? get statutEchec => getField<bool>('statut_echec');
  set statutEchec(bool? value) => setField<bool>('statut_echec', value);

  String? get nomUser => getField<String>('nom_user');
  set nomUser(String? value) => setField<String>('nom_user', value);

  double? get frais => getField<double>('frais');
  set frais(double? value) => setField<double>('frais', value);
}
