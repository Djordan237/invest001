import '../database.dart';

class VReseauUtilisateurTable extends SupabaseTable<VReseauUtilisateurRow> {
  @override
  String get tableName => 'v_reseau_utilisateur';

  @override
  VReseauUtilisateurRow createRow(Map<String, dynamic> data) =>
      VReseauUtilisateurRow(data);
}

class VReseauUtilisateurRow extends SupabaseDataRow {
  VReseauUtilisateurRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => VReseauUtilisateurTable();

  int? get parrainageId => getField<int>('parrainage_id');
  set parrainageId(int? value) => setField<int>('parrainage_id', value);

  String? get parrainId => getField<String>('parrain_id');
  set parrainId(String? value) => setField<String>('parrain_id', value);

  String? get filleulId => getField<String>('filleul_id');
  set filleulId(String? value) => setField<String>('filleul_id', value);

  int? get niveau => getField<int>('niveau');
  set niveau(int? value) => setField<int>('niveau', value);

  String? get email => getField<String>('email');
  set email(String? value) => setField<String>('email', value);

  int? get telephone => getField<int>('telephone');
  set telephone(int? value) => setField<int>('telephone', value);

  double? get ttRecharge => getField<double>('tt_recharge');
  set ttRecharge(double? value) => setField<double>('tt_recharge', value);

  DateTime? get dateInscription => getField<DateTime>('date_inscription');
  set dateInscription(DateTime? value) =>
      setField<DateTime>('date_inscription', value);
}
