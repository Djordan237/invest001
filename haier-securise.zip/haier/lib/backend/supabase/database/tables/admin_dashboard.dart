import '../database.dart';

class AdminDashboardTable extends SupabaseTable<AdminDashboardRow> {
  @override
  String get tableName => 'admin_dashboard';

  @override
  AdminDashboardRow createRow(Map<String, dynamic> data) =>
      AdminDashboardRow(data);
}

class AdminDashboardRow extends SupabaseDataRow {
  AdminDashboardRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => AdminDashboardTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  int? get totalUser => getField<int>('total_user');
  set totalUser(int? value) => setField<int>('total_user', value);

  int? get totalProduits => getField<int>('total_produits');
  set totalProduits(int? value) => setField<int>('total_produits', value);

  int? get totalDepotSucces => getField<int>('total_depot_succes');
  set totalDepotSucces(int? value) =>
      setField<int>('total_depot_succes', value);

  int? get totalDepotAttente => getField<int>('total_depot_attente');
  set totalDepotAttente(int? value) =>
      setField<int>('total_depot_attente', value);

  int? get totalRetraitSucces => getField<int>('total_retrait_succes');
  set totalRetraitSucces(int? value) =>
      setField<int>('total_retrait_succes', value);

  int? get totalRetraitAttente => getField<int>('total_retrait_attente');
  set totalRetraitAttente(int? value) =>
      setField<int>('total_retrait_attente', value);

  double? get Soldedepot => getField<double>('Solde_depot');
  set Soldedepot(double? value) => setField<double>('Solde_depot', value);

  double? get Solderetrait => getField<double>('Solde_retrait');
  set Solderetrait(double? value) => setField<double>('Solde_retrait', value);

  double? get soldedepot => getField<double>('solde_depot');
  set soldedepot(double? value) => setField<double>('solde_depot', value);

  double? get solderetrait => getField<double>('solde_retrait');
  set solderetrait(double? value) => setField<double>('solde_retrait', value);
}
