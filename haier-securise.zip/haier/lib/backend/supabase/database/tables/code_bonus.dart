import '../database.dart';

class CodeBonusTable extends SupabaseTable<CodeBonusRow> {
  @override
  String get tableName => 'code_bonus';

  @override
  CodeBonusRow createRow(Map<String, dynamic> data) => CodeBonusRow(data);
}

class CodeBonusRow extends SupabaseDataRow {
  CodeBonusRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => CodeBonusTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  String? get code => getField<String>('code');
  set code(String? value) => setField<String>('code', value);

  int? get montant => getField<int>('montant');
  set montant(int? value) => setField<int>('montant', value);

  int? get nbreActivation => getField<int>('nbre_activation');
  set nbreActivation(int? value) => setField<int>('nbre_activation', value);
}
