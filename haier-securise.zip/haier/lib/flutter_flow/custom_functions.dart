import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/flutter_flow/ff_builtin_enums.dart';
import '/backend/supabase/supabase.dart';
import '/auth/supabase_auth/auth_util.dart';

double? soustractionDouble(
  double? solde,
  double? montant,
) {
  return (solde ?? 0) - (montant ?? 0);
}

int? soustractionInt(
  int? montant1,
  int? montant2,
) {
  return (montant1 ?? 0) - (montant2 ?? 0);
}

double? soustractionDoubleInt(
  double? montant1,
  int? montant2,
) {
  return (montant1 ?? 0) - (montant2 ?? 0);
}

int? additionInt(
  int? actif1,
  int? actif2,
) {
  return (actif1 ?? 0) + (actif2 ?? 0);
}

double? additionDouble(
  double? solde,
  int? revenu,
) {
  return (solde ?? 0) + (revenu ?? 0);
}

double? additionDoubledouble(
  double? solde,
  double? revenu,
) {
  return (solde ?? 0) + (revenu ?? 0);
}

double? multiplication(
  int? montant,
  double? pourcentage,
) {
  return (montant ?? 0) * (pourcentage ?? 0);
}
