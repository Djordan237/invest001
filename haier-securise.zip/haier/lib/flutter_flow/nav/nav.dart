import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:go_router/go_router.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';

import '/backend/supabase/supabase.dart';

import '/auth/base_auth_user_provider.dart';
import '/auth/admin_guard.dart';

import '/main.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'serialization_util.dart';

import '/index.dart';

export 'package:go_router/go_router.dart';
export 'serialization_util.dart';

const kTransitionInfoKey = '__transition_info__';

GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

class AppStateNotifier extends ChangeNotifier {
  AppStateNotifier._();

  static AppStateNotifier? _instance;
  static AppStateNotifier get instance => _instance ??= AppStateNotifier._();

  BaseAuthUser? initialUser;
  BaseAuthUser? user;
  bool showSplashImage = true;
  String? _redirectLocation;

  /// Determines whether the app will refresh and build again when a sign
  /// in or sign out happens. This is useful when the app is launched or
  /// on an unexpected logout. However, this must be turned off when we
  /// intend to sign in/out and then navigate or perform any actions after.
  /// Otherwise, this will trigger a refresh and interrupt the action(s).
  bool notifyOnAuthChange = true;

  bool get loading => user == null || showSplashImage;
  bool get loggedIn => user?.loggedIn ?? false;
  bool get initiallyLoggedIn => initialUser?.loggedIn ?? false;
  bool get shouldRedirect => loggedIn && _redirectLocation != null;

  String getRedirectLocation() => _redirectLocation!;
  bool hasRedirect() => _redirectLocation != null;
  void setRedirectLocationIfUnset(String loc) => _redirectLocation ??= loc;
  void clearRedirectLocation() => _redirectLocation = null;

  /// Mark as not needing to notify on a sign in / out when we intend
  /// to perform subsequent actions (such as navigation) afterwards.
  void updateNotifyOnAuthChange(bool notify) => notifyOnAuthChange = notify;

  void update(BaseAuthUser newUser) {
    final shouldUpdate =
        user?.uid == null || newUser.uid == null || user?.uid != newUser.uid;
    initialUser ??= newUser;
    user = newUser;
    // Refresh the app on auth change unless explicitly marked otherwise.
    // No need to update unless the user has changed.
    if (notifyOnAuthChange && shouldUpdate) {
      notifyListeners();
    }
    // Once again mark the notifier as needing to update on auth change
    // (in order to catch sign in / out events).
    updateNotifyOnAuthChange(true);
  }

  void stopShowingSplashImage() {
    showSplashImage = false;
    notifyListeners();
  }
}

GoRouter createRouter(AppStateNotifier appStateNotifier) => GoRouter(
      initialLocation: '/',
      debugLogDiagnostics: true,
      refreshListenable: appStateNotifier,
      navigatorKey: appNavigatorKey,
      errorBuilder: (context, state) =>
          appStateNotifier.loggedIn ? AcceuilWidget() : InscriptionWidget(),
      routes: [
        FFRoute(
          name: '_initialize',
          path: '/',
          builder: (context, _) =>
              appStateNotifier.loggedIn ? AcceuilWidget() : InscriptionWidget(),
        ),
        FFRoute(
          name: Auth2Widget.routeName,
          path: Auth2Widget.routePath,
          builder: (context, params) => Auth2Widget(),
        ),
        FFRoute(
          name: Auth1Widget.routeName,
          path: Auth1Widget.routePath,
          builder: (context, params) => Auth1Widget(
            invitation: params.getParam(
              'invitation',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: AcceuilWidget.routeName,
          path: AcceuilWidget.routePath,
          requireAuth: true,
          builder: (context, params) => AcceuilWidget(),
        ),
        FFRoute(
          name: ProduitsWidget.routeName,
          path: ProduitsWidget.routePath,
          requireAuth: true,
          builder: (context, params) => ProduitsWidget(),
        ),
        FFRoute(
          name: DetailProduitWidget.routeName,
          path: DetailProduitWidget.routePath,
          requireAuth: true,
          builder: (context, params) => DetailProduitWidget(
            produitId: params.getParam(
              'produitId',
              ParamType.int,
            ),
            image: params.getParam(
              'image',
              ParamType.String,
            ),
            nom: params.getParam(
              'nom',
              ParamType.String,
            ),
            prix: params.getParam(
              'prix',
              ParamType.int,
            ),
            revenujj: params.getParam(
              'revenujj',
              ParamType.int,
            ),
            revenutt: params.getParam(
              'revenutt',
              ParamType.int,
            ),
            taux: params.getParam(
              'taux',
              ParamType.String,
            ),
            cycle: params.getParam(
              'cycle',
              ParamType.int,
            ),
            limite: params.getParam(
              'limite',
              ParamType.int,
            ),
            details: params.getParam(
              'details',
              ParamType.String,
            ),
            point: params.getParam(
              'point',
              ParamType.double,
            ),
          ),
        ),
        FFRoute(
          name: ProduitUserWidget.routeName,
          path: ProduitUserWidget.routePath,
          requireAuth: true,
          builder: (context, params) => ProduitUserWidget(),
        ),
        FFRoute(
          name: InvitationWidget.routeName,
          path: InvitationWidget.routePath,
          requireAuth: true,
          builder: (context, params) => InvitationWidget(),
        ),
        FFRoute(
          name: EquipeWidget.routeName,
          path: EquipeWidget.routePath,
          requireAuth: true,
          builder: (context, params) => EquipeWidget(),
        ),
        FFRoute(
          name: ProfileWidget.routeName,
          path: ProfileWidget.routePath,
          requireAuth: true,
          builder: (context, params) => ProfileWidget(),
        ),
        FFRoute(
          name: RechargeWidget.routeName,
          path: RechargeWidget.routePath,
          requireAuth: true,
          builder: (context, params) => RechargeWidget(),
        ),
        FFRoute(
          name: RetraitWidget.routeName,
          path: RetraitWidget.routePath,
          requireAuth: true,
          builder: (context, params) => RetraitWidget(),
        ),
        FFRoute(
          name: ActualiterWidget.routeName,
          path: ActualiterWidget.routePath,
          requireAuth: true,
          builder: (context, params) => ActualiterWidget(),
        ),
        FFRoute(
          name: PartageCaptureWidget.routeName,
          path: PartageCaptureWidget.routePath,
          requireAuth: true,
          builder: (context, params) => PartageCaptureWidget(),
        ),
        FFRoute(
          name: LoterieWidget.routeName,
          path: LoterieWidget.routePath,
          requireAuth: true,
          builder: (context, params) => LoterieWidget(),
        ),
        FFRoute(
          name: HistoriqueDepotWidget.routeName,
          path: HistoriqueDepotWidget.routePath,
          requireAuth: true,
          builder: (context, params) => HistoriqueDepotWidget(),
        ),
        FFRoute(
          name: InscriptionWidget.routeName,
          path: InscriptionWidget.routePath,
          builder: (context, params) => InscriptionWidget(
            ref: params.getParam(
              'ref',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: HistoriqueRetraitWidget.routeName,
          path: HistoriqueRetraitWidget.routePath,
          requireAuth: true,
          builder: (context, params) => HistoriqueRetraitWidget(),
        ),
        FFRoute(
          name: AdminAcceuilWidget.routeName,
          path: AdminAcceuilWidget.routePath,
          requireAuth: true,
          builder: (context, params) => const AdminGuard(
            child: AdminAcceuilWidget(),
          ),
        ),
        FFRoute(
          name: AdminDepotsWidget.routeName,
          path: AdminDepotsWidget.routePath,
          requireAuth: true,
          builder: (context, params) => const AdminGuard(
            child: AdminDepotsWidget(),
          ),
        ),
        FFRoute(
          name: AdminRetraitWidget.routeName,
          path: AdminRetraitWidget.routePath,
          requireAuth: true,
          builder: (context, params) => const AdminGuard(
            child: AdminRetraitWidget(),
          ),
        ),
        FFRoute(
          name: AdminUsersWidget.routeName,
          path: AdminUsersWidget.routePath,
          requireAuth: true,
          builder: (context, params) => const AdminGuard(
            child: AdminUsersWidget(),
          ),
        ),
        FFRoute(
          name: OmWidget.routeName,
          path: OmWidget.routePath,
          requireAuth: true,
          builder: (context, params) => OmWidget(
            montant: params.getParam(
              'montant',
              ParamType.int,
            ),
            logo: params.getParam(
              'logo',
              ParamType.String,
            ),
            nomCarte: params.getParam(
              'nomCarte',
              ParamType.String,
            ),
            numero: params.getParam(
              'numero',
              ParamType.String,
            ),
            reseaux: params.getParam(
              'reseaux',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: MtnWidget.routeName,
          path: MtnWidget.routePath,
          requireAuth: true,
          builder: (context, params) => MtnWidget(
            montant: params.getParam(
              'montant',
              ParamType.String,
            ),
          ),
        )
      ].map((r) => r.toRoute(appStateNotifier)).toList(),
    );

extension NavParamExtensions on Map<String, String?> {
  Map<String, String> get withoutNulls => Map.fromEntries(
        entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
}

extension NavigationExtensions on BuildContext {
  void goNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : goNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void pushNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : pushNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void safePop() {
    // If there is only one route on the stack, navigate to the initial
    // page instead of popping.
    if (canPop()) {
      pop();
    } else {
      go('/');
    }
  }
}

extension GoRouterExtensions on GoRouter {
  AppStateNotifier get appState => AppStateNotifier.instance;
  void prepareAuthEvent([bool ignoreRedirect = false]) =>
      appState.hasRedirect() && !ignoreRedirect
          ? null
          : appState.updateNotifyOnAuthChange(false);
  bool shouldRedirect(bool ignoreRedirect) =>
      !ignoreRedirect && appState.hasRedirect();
  void clearRedirectLocation() => appState.clearRedirectLocation();
  void setRedirectLocationIfUnset(String location) =>
      appState.updateNotifyOnAuthChange(false);
}

extension _GoRouterStateExtensions on GoRouterState {
  Map<String, dynamic> get extraMap =>
      extra != null ? extra as Map<String, dynamic> : {};
  Map<String, dynamic> get allParams => <String, dynamic>{}
    ..addAll(pathParameters)
    ..addAll(uri.queryParameters)
    ..addAll(extraMap);
  TransitionInfo get transitionInfo => extraMap.containsKey(kTransitionInfoKey)
      ? extraMap[kTransitionInfoKey] as TransitionInfo
      : TransitionInfo.appDefault();
}

class FFParameters {
  FFParameters(this.state, [this.asyncParams = const {}]);

  final GoRouterState state;
  final Map<String, Future<dynamic> Function(String)> asyncParams;

  Map<String, dynamic> futureParamValues = {};

  // Parameters are empty if the params map is empty or if the only parameter
  // present is the special extra parameter reserved for the transition info.
  bool get isEmpty =>
      state.allParams.isEmpty ||
      (state.allParams.length == 1 &&
          state.extraMap.containsKey(kTransitionInfoKey));
  bool isAsyncParam(MapEntry<String, dynamic> param) =>
      asyncParams.containsKey(param.key) && param.value is String;
  bool get hasFutures => state.allParams.entries.any(isAsyncParam);
  Future<bool> completeFutures() => Future.wait(
        state.allParams.entries.where(isAsyncParam).map(
          (param) async {
            final doc = await asyncParams[param.key]!(param.value)
                .onError((_, __) => null);
            if (doc != null) {
              futureParamValues[param.key] = doc;
              return true;
            }
            return false;
          },
        ),
      ).onError((_, __) => [false]).then((v) => v.every((e) => e));

  dynamic getParam<T>(
    String paramName,
    ParamType type, {
    bool isList = false,
  }) {
    if (futureParamValues.containsKey(paramName)) {
      return futureParamValues[paramName];
    }
    if (!state.allParams.containsKey(paramName)) {
      return null;
    }
    final param = state.allParams[paramName];
    // Got parameter from `extras`, so just directly return it.
    if (param is! String) {
      return param;
    }
    // Return serialized value.
    return deserializeParam<T>(
      param,
      type,
      isList,
    );
  }
}

class FFRoute {
  const FFRoute({
    required this.name,
    required this.path,
    required this.builder,
    this.requireAuth = false,
    this.asyncParams = const {},
    this.routes = const [],
  });

  final String name;
  final String path;
  final bool requireAuth;
  final Map<String, Future<dynamic> Function(String)> asyncParams;
  final Widget Function(BuildContext, FFParameters) builder;
  final List<GoRoute> routes;

  GoRoute toRoute(AppStateNotifier appStateNotifier) => GoRoute(
        name: name,
        path: path,
        redirect: (context, state) {
          if (appStateNotifier.shouldRedirect) {
            final redirectLocation = appStateNotifier.getRedirectLocation();
            appStateNotifier.clearRedirectLocation();
            return redirectLocation;
          }

          if (requireAuth && !appStateNotifier.loggedIn) {
            appStateNotifier.setRedirectLocationIfUnset(state.uri.toString());
            return '/inscription';
          }
          return null;
        },
        pageBuilder: (context, state) {
          fixStatusBarOniOS16AndBelow(context);
          final ffParams = FFParameters(state, asyncParams);
          final page = ffParams.hasFutures
              ? FutureBuilder(
                  future: ffParams.completeFutures(),
                  builder: (context, _) => builder(context, ffParams),
                )
              : builder(context, ffParams);
          final child = appStateNotifier.loading
              ? Center(
                  child: SizedBox(
                    width: 50.0,
                    height: 50.0,
                    child: SpinKitDoubleBounce(
                      color: FlutterFlowTheme.of(context).primary,
                      size: 50.0,
                    ),
                  ),
                )
              : page;

          final transitionInfo = state.transitionInfo;
          return transitionInfo.hasTransition
              ? CustomTransitionPage(
                  key: state.pageKey,
                  name: state.name,
                  child: child,
                  transitionDuration: transitionInfo.duration,
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          PageTransition(
                    type: transitionInfo.transitionType,
                    duration: transitionInfo.duration,
                    reverseDuration: transitionInfo.duration,
                    alignment: transitionInfo.alignment,
                    child: child,
                  ).buildTransitions(
                    context,
                    animation,
                    secondaryAnimation,
                    child,
                  ),
                )
              : MaterialPage(
                  key: state.pageKey, name: state.name, child: child);
        },
        routes: routes,
      );
}

class TransitionInfo {
  const TransitionInfo({
    required this.hasTransition,
    this.transitionType = PageTransitionType.fade,
    this.duration = const Duration(milliseconds: 300),
    this.alignment,
  });

  final bool hasTransition;
  final PageTransitionType transitionType;
  final Duration duration;
  final Alignment? alignment;

  static TransitionInfo appDefault() => TransitionInfo(hasTransition: false);
}

class RootPageContext {
  const RootPageContext(this.isRootPage, [this.errorRoute]);
  final bool isRootPage;
  final String? errorRoute;

  static bool isInactiveRootPage(BuildContext context) {
    final rootPageContext = context.read<RootPageContext?>();
    final isRootPage = rootPageContext?.isRootPage ?? false;
    final location = GoRouterState.of(context).uri.toString();
    return isRootPage &&
        location != '/' &&
        location != rootPageContext?.errorRoute;
  }

  static Widget wrap(Widget child, {String? errorRoute}) => Provider.value(
        value: RootPageContext(true, errorRoute),
        child: child,
      );
}

extension GoRouterLocationExtension on GoRouter {
  String getCurrentLocation() {
    final RouteMatch lastMatch = routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }
}
