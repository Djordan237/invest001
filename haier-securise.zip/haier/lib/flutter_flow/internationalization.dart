import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['fr', 'en'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? frText = '',
    String? enText = '',
  }) =>
      [frText, enText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

/// Used if the locale is not supported by GlobalMaterialLocalizations.
class FallbackMaterialLocalizationDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const FallbackMaterialLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<MaterialLocalizations> load(Locale locale) async =>
      SynchronousFuture<MaterialLocalizations>(
        const DefaultMaterialLocalizations(),
      );

  @override
  bool shouldReload(FallbackMaterialLocalizationDelegate old) => false;
}

/// Used if the locale is not supported by GlobalCupertinoLocalizations.
class FallbackCupertinoLocalizationDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const FallbackCupertinoLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<CupertinoLocalizations> load(Locale locale) =>
      SynchronousFuture<CupertinoLocalizations>(
        const DefaultCupertinoLocalizations(),
      );

  @override
  bool shouldReload(FallbackCupertinoLocalizationDelegate old) => false;
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

bool _isSupportedLocale(Locale locale) {
  final language = locale.toString();
  return FFLocalizations.languages().contains(
    language.endsWith('_')
        ? language.substring(0, language.length - 1)
        : language,
  );
}

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // Auth2
  {
    'dloh8re2': {
      'fr': 'Bonjour, bon retour sur ',
      'en': 'Hello, welcome back to',
    },
    '3jamxrw4': {
      'fr': 'Haier',
      'en': 'Haier',
    },
    '30t273vc': {
      'fr': 'Adresse Email',
      'en': 'E-mail address',
    },
    'r0zuanha': {
      'fr': 'Veuillez entrer Email',
      'en': 'Please enter your email address.',
    },
    'zhnxfbhe': {
      'fr': 'Mot de passe',
      'en': 'Password',
    },
    'mp87sgyn': {
      'fr': 'Veuillez entrer le mot de passe',
      'en': 'Please enter the password',
    },
    'c4vfxsrl': {
      'fr': 'Connexion immédiate',
      'en': 'Instant connection',
    },
    'mt0ejo7n': {
      'fr': 'Inscription rapide',
      'en': 'Quick registration',
    },
    'rwk068ly': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // Auth1
  {
    '6pht5vz3': {
      'fr': 'Bonjour, bienvenue chez ',
      'en': 'Hello, welcome to',
    },
    'yfu1wtxm': {
      'fr': 'Haier',
      'en': 'Haier',
    },
    '8r5vckvi': {
      'fr': '+226',
      'en': '+237',
    },
    'd76cibnd': {
      'fr': '+226',
      'en': '+237',
    },
    '04q6368j': {
      'fr': 'Search...',
      'en': 'Search...',
    },
    '8r24yxpu': {
      'fr': '+226',
      'en': '+226',
    },
    '0jbe7uah': {
      'fr': '+229',
      'en': '+229',
    },
    'mb02t5sg': {
      'fr': '+228',
      'en': '+228',
    },
    '5jmmvmao': {
      'fr': 'Téléphone',
      'en': 'Phone',
    },
    'vd5m08zx': {
      'fr': 'Email',
      'en': 'E-mail',
    },
    '0fqaisrg': {
      'fr': 'Mot de passe',
      'en': 'Password',
    },
    'l3y3zljr': {
      'fr': 'Mot de passe',
      'en': 'Password',
    },
    '32yy44x7': {
      'fr': 'Inscription immédiate',
      'en': 'Immediate registration',
    },
    'hwhleirk': {
      'fr': 'connexion',
      'en': 'connection',
    },
    'aygqgril': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // acceuil
  {
    'zvk72uay': {
      'fr': 'Recharge',
      'en': 'Recharge',
    },
    'ary6i3bo': {
      'fr': 'Retrait',
      'en': 'Withdrawal',
    },
    'nhm8mgxx': {
      'fr': 'Mon produit',
      'en': 'My product',
    },
    'wyuya1m3': {
      'fr': 'Mon équipe',
      'en': 'My team',
    },
    '94430p8b': {
      'fr': 'HAIER SMART HOME',
      'en': 'HAIER SMART HOME',
    },
    'd015a0np': {
      'fr':
          'Haier Smart Home est un leader mondial des solutions pour la maison connectée, créant des expériences de vie intelligentes et complètes grâce à l\'innovation technologique. Avec des marques reconnues telles que Haier, Casarte et Leader, l\'entreprise est présente dans plus de 200 pays et régions et, grâce à son envergure mondiale et à ses opérations locales, elle est à la pointe du développement haut de gamme, intelligent et durable du secteur.',
      'en':
          'Haier Smart Home is a global leader in connected home solutions, creating intelligent and comprehensive living experiences through technological innovation. With renowned brands such as Haier, Casarte, and Leader, the company operates in over 200 countries and regions and, thanks to its global reach and local operations, is at the forefront of premium, smart, and sustainable development in the industry.',
    },
    'al1gkwqs': {
      'fr':
          'Le président de la République du Togo, SEM Faure Essozimna Gnassingbé, et sa délégation visitent Haier Biomedical (Photo : Zhao Jianpeng, Qingdao Daily).',
      'en':
          'The President of the Republic of Togo, H.E. Faure Essozimna Gnassingbé, and his delegation visit Haier Biomedical (Photo: Zhao Jianpeng, Qingdao Daily).',
    },
    'yp1mbhz2': {
      'fr':
          'Le renforcement de la solidarité et de la coopération avec les pays africains constitue une priorité stratégique pour la Chine. Ces dernières années, la Chine a aligné son initiative « la Ceinture et la Route » et son Initiative mondiale pour le développement sur l’Agenda 2063 de l’Union africaine et sur diverses stratégies nationales de développement à travers le continent. Grâce à des cadres de collaboration tels que les « Dix plans de coopération », les « Huit grandes initiatives » et désormais les « Neuf projets », la coopération chino-africaine a connu une amélioration continue.…',
      'en':
          'Strengthening solidarity and cooperation with African countries is a strategic priority for China. In recent years, China has aligned its Belt and Road Initiative and its Global Development Initiative with the African Union\'s Agenda 2063 and various national development strategies across the continent. Through collaborative frameworks such as the Ten Cooperation Plans, the Eight Major Initiatives, and now the Nine Projects, China-Africa cooperation has seen continuous improvement.',
    },
    'kn8thmor': {
      'fr': 'Actualités recommandées',
      'en': 'Recommended news',
    },
    'nm1sg09p': {
      'fr': 'Recrutement de nouveaux investisseurs en Afrique',
      'en': 'Recruiting new investors in Africa',
    },
    't15ga59g': {
      'fr':
          'Comme eux, vous pouvez rejoindre l\'équipe Haier Smart House et profiter de nos avantages.',
      'en':
          'Like them, you can join the Haier Smart House team and enjoy our benefits.',
    },
    'ns10kb8c': {
      'fr': '2026-04-28',
      'en': '2026-04-27T23:00:00Z',
    },
    'n9vc7fjn': {
      'fr': 'Haier désormais disponible Cameroun',
      'en': 'Haier now available in Cameroon',
    },
    'pctnbq21': {
      'fr':
          'Rencontre bilatérale avec le Premier ministre du Cameroun, S.E. Joseph Ngute',
      'en':
          'Bilateral meeting with the Prime Minister of Cameroon, H.E. Joseph Ngute',
    },
    'v1rzupj2': {
      'fr': '2026-04-26',
      'en': '2026-04-25T23:00:00Z',
    },
    '9hb6k1ak': {
      'fr': 'Togo : Accords avec HAIER et RELP pour booster l\'économie locale',
      'en': 'Togo: Agreements with HAIER and RELP to boost the local economy',
    },
    '5kszswys': {
      'fr':
          'Les utilisatuer Togolais peuvent profité des bienfait de Haier Tech.',
      'en': 'Togolese users can benefit from the advantages of Haier Tech.',
    },
    'uarvo0xb': {
      'fr': '2026-04-26',
      'en': '2026-04-25T23:00:00Z',
    },
    'z3q110nf': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // Produits
  {
    'l9v7en3h': {
      'fr': 'Tous',
      'en': 'All',
    },
    '00ghdedk': {
      'fr': 'Mon',
      'en': 'My',
    },
    'uy0cg7gw': {
      'fr': 'Bonus',
      'en': 'Bonus',
    },
    'alhu7djx': {
      'fr': ' ',
      'en': '',
    },
    '4lht8ciq': {
      'fr': 'Hello World',
      'en': 'Hello World',
    },
    '9lzb2dcd': {
      'fr': 'Cycle',
      'en': 'Cycle',
    },
    'uxmhiqxu': {
      'fr': 'Intérêt total',
      'en': 'Total interest',
    },
    'wky2um4a': {
      'fr': '268.32%',
      'en': '268.32%',
    },
    'tatqsjf8': {
      'fr': 'Prix du produit',
      'en': 'Product price',
    },
    'n9nhy1cn': {
      'fr': 'Revenu journalier',
      'en': 'Daily income',
    },
    '05hxo6rm': {
      'fr': 'Revenu total',
      'en': 'Total income',
    },
    '0xluv5bd': {
      'fr': 'Investir maintenant',
      'en': 'Invest now',
    },
    'tgfs25ft': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // detail_produit
  {
    '7ht0him0': {
      'fr': 'Revenu quotidien:',
      'en': 'Daily income:',
    },
    'wd3sxop5': {
      'fr': 'Total des gains:',
      'en': 'Total earnings:',
    },
    '28aoc4pb': {
      'fr': 'Taux de réponse',
      'en': 'Response rate',
    },
    'p8yec773': {
      'fr': 'Durée de détention',
      'en': 'Length of detention',
    },
    '776f3fzs': {
      'fr': 'Total Points',
      'en': 'Total Points',
    },
    '6psy3hf6': {
      'fr': 'Recharger le compte',
      'en': 'Top up the account',
    },
    'tf8y0mgd': {
      'fr': 'Acheter le produit',
      'en': 'Buy the product',
    },
    'ag8fem3t': {
      'fr': ' Description du produit',
      'en': 'Product description',
    },
    'x9fhzvyy': {
      'fr':
          'Ce produit ne nécessite aucun entretien régulier. Vous pouvez percevoir votre salaire du lundi au dimanche sans interruption.',
      'en':
          'This product requires no regular maintenance. You can receive your salary from Monday to Sunday without interruption.',
    },
    '1f8n1zpv': {
      'fr': 'Détails du produit',
      'en': 'Product details',
    },
    '816mmiza': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // produit_user
  {
    '1v4t35o5': {
      'fr': 'Tous',
      'en': 'All',
    },
    '7xa6bzzr': {
      'fr': 'Mon',
      'en': 'My',
    },
    '0kxvc1jh': {
      'fr': 'Revenu quotidien',
      'en': 'Daily income',
    },
    'lgrurpgj': {
      'fr': 'Total des gains ',
      'en': 'Total earnings',
    },
    'h07j6lfc': {
      'fr': ' /',
      'en': '/',
    },
    '6dkvot41': {
      'fr': 'CFA',
      'en': 'CFA',
    },
    '64vo4ruk': {
      'fr': '/65\$',
      'en': '\$65',
    },
    'h6qyjw45': {
      'fr': 'Date d\'entrée',
      'en': 'Entry date',
    },
    'rrvpt80c': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // invitation
  {
    't9g7fu7c': {
      'fr': 'Inviter des amis',
      'en': 'Invite friends',
    },
    'byjae5gb': {
      'fr': 'Rejoignez-nous pour obtenir plus d\'argent',
      'en': 'Join us to earn more money',
    },
    'h3md2z93': {
      'fr': 'Voir mon équipe',
      'en': 'See my team',
    },
    'uxvncvdp': {
      'fr': 'Mon lien d\'invitation',
      'en': 'My invitation link',
    },
    '61daabvk': {
      'fr': 'Copier le lien',
      'en': 'Copy link',
    },
    'ob13vqbk': {
      'fr': 'Veuillez noter:',
      'en': 'Please note:',
    },
    'wklcst7l': {
      'fr': '1. Les recommandations de Niveau 1 vous donnent',
      'en': '1. Level 1 recommendations give you',
    },
    '75d3oey8': {
      'fr': ' 25%',
      'en': '10%',
    },
    'zy7jvn8s': {
      'fr': '1. Les recommandations directes vous donnent',
      'en': '1. Direct recommendations give you',
    },
    'g4uu7mwb': {
      'fr': '2. Les recommandations de Niveau 2 vous donnent',
      'en': '2. The Level 2 recommendations give you',
    },
    'y674lwd2': {
      'fr': ' 3%',
      'en': '5%',
    },
    'dvm9o2zn': {
      'fr': '1. Les recommandations directes vous donnent',
      'en': '1. Direct recommendations give you',
    },
    'zveovj62': {
      'fr': '3. Les recommandations de Niveau 3 vous donnent',
      'en': '3. Level 3 recommendations give you',
    },
    'fwu0tuia': {
      'fr': ' 2%',
      'en': '2%',
    },
    'xuweyz5y': {
      'fr': '1. Les recommandations directes vous donnent',
      'en': '1. Direct recommendations give you',
    },
    'o2ic3ia1': {
      'fr': '2. Vous recevrez un salaire totale de',
      'en': '2. You will receive a total salary of',
    },
    '30ws83lh': {
      'fr': ' 30% ',
      'en': '17%',
    },
    'czuimze9': {
      'fr': 'des revenus de vos invités chaque jours dans votre compte.',
      'en': 'your guests\' income is deposited into your account every day.',
    },
    'zlddct1o': {
      'fr': '2. Vous recevrez un salaire de',
      'en': '2. You will receive a salary of',
    },
    'tu5o6jgj': {
      'fr':
          '3. Si vous rencontrez des problèmes de paiement, veuillez contacter le service client.',
      'en':
          '3. If you encounter any payment problems, please contact customer service.',
    },
    'do2rcw4s': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // equipe
  {
    'wrtjixxz': {
      'fr': 'Taille de l\'équipe',
      'en': 'Team size',
    },
    'udneywqz': {
      'fr': 'Salaire de l\'équipe',
      'en': 'Team salary',
    },
    'z57wgels': {
      'fr': 'Bénéfice LV1',
      'en': 'LV1 Benefit',
    },
    'l78mio97': {
      'fr': 'Bénéfice LV2',
      'en': 'LV2 Benefit',
    },
    '6mbo4o60': {
      'fr': 'Bénéfice LV3',
      'en': 'LV3 Benefit',
    },
    'dmz5x74c': {
      'fr': 'Copier le lien',
      'en': 'Copy link',
    },
    'ndqfurot': {
      'fr': 'Niveau',
      'en': 'Level',
    },
    'es1s3g1x': {
      'fr': 'User:  ',
      'en': 'User:',
    },
    '9yanecmp': {
      'fr': 'User: ',
      'en': 'User:',
    },
    'alot8tgz': {
      'fr': 'Recharge: ',
      'en': 'Recharge:',
    },
    'd5mjzocf': {
      'fr': ' CFA',
      'en': 'CFA',
    },
    'p227crje': {
      'fr': 'User: ',
      'en': 'User:',
    },
    'm8lag0vw': {
      'fr': 'Mon équipe',
      'en': 'My team',
    },
    'y94sqe0r': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // profile
  {
    '0x76oju5': {
      'fr': 'ID:',
      'en': 'ID:',
    },
    '24yb5va3': {
      'fr': 'Mon',
      'en': 'My',
    },
    'rhnawru9': {
      'fr': 'Recharge',
      'en': 'Recharge',
    },
    '57lzk02h': {
      'fr': 'Retrait',
      'en': 'Withdrawal',
    },
    'yuoqfg46': {
      'fr': 'Equipe',
      'en': 'Team',
    },
    'up8sfoyx': {
      'fr': 'Sortir',
      'en': 'To go out',
    },
    '1zcjkfx7': {
      'fr': 'Solde disponible:',
      'en': 'Available balance:',
    },
    'w6emdtao': {
      'fr': '.0',
      'en': '.0',
    },
    'uj9z49ch': {
      'fr': 'CFA',
      'en': 'CFA',
    },
    'iqvwwx9v': {
      'fr': 'Hello World',
      'en': 'Hello World',
    },
    'gslfsxzz': {
      'fr': 'Bénéfice du produit:',
      'en': 'Product benefit:',
    },
    '70i57355': {
      'fr': '.0',
      'en': '.0',
    },
    'iifgcicr': {
      'fr': 'CFA',
      'en': 'CFA',
    },
    '7fe78r0b': {
      'fr': 'Hello World',
      'en': 'Hello World',
    },
    'mj04369n': {
      'fr': 'Bénéfice de l\'équipe:',
      'en': 'Team benefit:',
    },
    'gqavoydz': {
      'fr': '.0',
      'en': '.0',
    },
    'oulhr6qu': {
      'fr': 'CFA',
      'en': 'CFA',
    },
    '6faz0ifh': {
      'fr': 'Hello World',
      'en': 'Hello World',
    },
    'g856xmuk': {
      'fr': 'Mon équipe',
      'en': 'My team',
    },
    'ks0wdd8q': {
      'fr': 'Historique des recharges',
      'en': 'Top-up history',
    },
    'mo1kkzyw': {
      'fr': 'Historique des retraits',
      'en': 'Withdrawal history',
    },
    'frjkujhx': {
      'fr': 'Service client',
      'en': 'Customer service',
    },
    'uo5bgsav': {
      'fr': 'Inviter des amis',
      'en': 'Invite friends',
    },
    'oj7gwsin': {
      'fr': 'Total de points ',
      'en': 'Total points',
    },
    'v424d56i': {
      'fr': 'Télécharger l\'application mobile',
      'en': 'Download the mobile app',
    },
    'l4rcdbo8': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // recharge
  {
    'khhr50pe': {
      'fr': 'Recharge',
      'en': 'Recharge',
    },
    '6tgt3sds': {
      'fr': 'CFA',
      'en': 'CFA',
    },
    '7g21ps1r': {
      'fr': 'Veuillez saisir le montant de la recharge...',
      'en': 'Please enter the top-up amount...',
    },
    'wegg2l64': {
      'fr': '3000',
      'en': '4000',
    },
    'ri3idci4': {
      'fr': '8000',
      'en': '12000',
    },
    'sg4l42t4': {
      'fr': '15000',
      'en': '26000',
    },
    'agwysg0p': {
      'fr': '25000',
      'en': '50000',
    },
    'ey9mhfu4': {
      'fr': '50000',
      'en': '120000',
    },
    'hclqeyox': {
      'fr': '120000',
      'en': '210,000',
    },
    'de0864hq': {
      'fr':
          'Les recharges sont bien effectuer via la méthode de paiement correspondante.',
      'en':
          'Top-ups are successfully processed via the corresponding payment method.',
    },
    '54oov8mj': {
      'fr': 'Recharge',
      'en': 'Recharge',
    },
    '7tfbzlwk': {
      'fr': 'Veuillez noter:',
      'en': 'Please note:',
    },
    'm20a0nlc': {
      'fr': '1. Recharge minimale',
      'en': '1. Minimum charge',
    },
    'bf22kqs3': {
      'fr': 'CFA 3000',
      'en': 'CFA 4000',
    },
    'lp3abden': {
      'fr': '2. Recharge maximale direct',
      'en': '2. Maximum direct charging',
    },
    '35afiblt': {
      'fr': 'CFA 1 000 000',
      'en': 'CFA 1,000,000',
    },
    'qu4gtofp': {
      'fr':
          '3. Apres le paiement, veuillez saisir l\'identifiant de la transaction sur la page de paiement, sinon votre compte sera affecté',
      'en':
          '3. After payment, please enter the transaction ID on the payment page, otherwise your account will be affected.',
    },
    'bumv70yg': {
      'fr':
          '4. Si vous rencontrez des problèmes de paiement, veuillez contacter le service client.',
      'en':
          '4. If you encounter any payment problems, please contact customer service.',
    },
    'jnypwdyp': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // retrait
  {
    '0sj4ehop': {
      'fr': 'Retrait ',
      'en': 'Withdrawal',
    },
    'ko64g2kc': {
      'fr': 'CFA',
      'en': 'CFA',
    },
    'mmc0obd8': {
      'fr': 'Disponible pour retrait:',
      'en': 'Available for pickup:',
    },
    'w10rxqse': {
      'fr': '1000',
      'en': '1000',
    },
    'mcw8x53t': {
      'fr': '3000',
      'en': '3000',
    },
    'b0g9jmjq': {
      'fr': '10 000',
      'en': '10,000',
    },
    '7615txk9': {
      'fr': '25 000',
      'en': '25,000',
    },
    'g7kkwcma': {
      'fr': '60 000',
      'en': '60,000',
    },
    'h24nriji': {
      'fr': '150 000',
      'en': '150,000',
    },
    'xxug9o7e': {
      'fr': 'Entrez votre numéro de compte',
      'en': 'Enter your account number',
    },
    '3ej6cllv': {
      'fr': 'Entrez votre nom',
      'en': 'Enter your name',
    },
    'ksrknx9v': {
      'fr': 'Retrait',
      'en': 'Withdrawal',
    },
    'ruq0cdd4': {
      'fr': 'Réception sous 1-2 heures, Frais',
      'en': 'Delivery within 1-2 hours, Fees',
    },
    'bwf25f9p': {
      'fr': '18%',
      'en': '10%',
    },
    'atga9wjj': {
      'fr': 'Veuillez noter:',
      'en': 'Please note:',
    },
    'i64erbs9': {
      'fr': '1. Retrait minimale',
      'en': '1. Minimum withdrawal',
    },
    'xi9btwmx': {
      'fr': 'CFA 1000',
      'en': 'CFA 1000',
    },
    '2sostyox': {
      'fr': '2. Retrait maximum',
      'en': '2. Maximum withdrawal',
    },
    'qbm853hq': {
      'fr': 'CFA 200 000',
      'en': 'CFA 200,000',
    },
    '0ufgibx5': {
      'fr':
          '3. Les retraits sont disponnile du Lundi à Dimanche entre 9h et 17h',
      'en':
          '3. Withdrawals are available from Monday to Saturday between 8am and 6pm',
    },
    'xrv7e10m': {
      'fr': '4. Exemple: demande de retrait',
      'en': '4. Example: withdrawal request',
    },
    '3u7r89vr': {
      'fr': 'CFA 10 000',
      'en': 'CFA 10,000',
    },
    'bygetsqe': {
      'fr': 'Reçu réel',
      'en': 'Actual receipt',
    },
    '6zzv35b8': {
      'fr': 'CFA 8 200',
      'en': 'CFA 9,000',
    },
    'cl065ca4': {
      'fr':
          '5. Vous devez acheter au minimum un équipement pour éffectuer un retrait',
      'en':
          '5. You must purchase at least one piece of equipment to make a withdrawal',
    },
    '2iur8jja': {
      'fr': '6. Vous pouvez éffectuer un maximum de 2 retrait par jour',
      'en':
          '5. You must purchase at least one piece of equipment to make a withdrawal',
    },
    '7x5p1ivy': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // actualiter
  {
    'p2fhno4j': {
      'fr':
          'Partager une preuve de retrait avec la communauté et recevez un bonus en espèce compris entre ',
      'en':
          'Share proof of withdrawal with the community and receive a cash bonus of between',
    },
    '0u5bjyw6': {
      'fr': '200-2000CFA ',
      'en': '200-2000 CFA',
    },
    '2lvs743m': {
      'fr':
          'Partager une preuve de retrait avec la communauté et recevez un bonus en espèce compris entre 200-2000CFA',
      'en':
          'Share proof of withdrawal with the community and receive a cash bonus of between 200-2000 CFA',
    },
    '6t6g6ixd': {
      'fr': 'Utilisateur: ',
      'en': 'User:',
    },
    'kf80i797': {
      'fr': 'Utilisateur:',
      'en': 'User:',
    },
    'rad4o4fk': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // partage_capture
  {
    '1nmkpws1': {
      'fr': 'Description...',
      'en': 'Description...',
    },
    '2b08t2ag': {
      'fr': 'Partager ',
      'en': 'Share',
    },
    'xikmccd9': {
      'fr': 'Description... is required',
      'en': 'Description... is required',
    },
    'mj79azu1': {
      'fr': 'Please choose an option from the dropdown',
      'en': 'Please choose an option from the dropdown',
    },
    'fm6qmqk7': {
      'fr': 'Ajouter une preuve de retrait',
      'en': 'Add proof of withdrawal',
    },
    'y15ocvvf': {
      'fr': 'Rassurez vous de la véracité des informations.',
      'en': 'Rest assured that the information is accurate.',
    },
    '5z4h040j': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // loterie
  {
    'o9m4ylgj': {
      'fr': 'Veuillez noter:',
      'en': 'Please note:',
    },
    '6erk34w9': {
      'fr': '1. Prix disponibles: ',
      'en': '1. Prices available:',
    },
    'oqqg5k12': {
      'fr':
          '500CFA, 2000CFA, 20 000CFA, 100 000CFA, 200 000CFA, Iphone 16 PM, Yamaha, BMW X5',
      'en':
          '500CFA, 2000CFA, 20,000CFA, 100,000CFA, 200,000CFA, Iphone 16 PM, Yamaha, BMW X5',
    },
    '7h2bube8': {
      'fr':
          '1. Prix disponibles: 500CFA, 2000CFA, 20 000CFA, 100 000CFA, 200 000CFA, Iphone 16 PM, Yamaha, BMW X5',
      'en':
          '1. Prices available: 500CFA, 2000CFA, 20,000CFA, 100,000CFA, 200,000CFA, Iphone 16 PM, Yamaha, BMW X5',
    },
    'q0oz3nf1': {
      'fr': '2. Les gains seront ajoutés directement à votre compte',
      'en': '2. The winnings will be added directly to your account',
    },
    'ihtz8wdv': {
      'fr':
          '3. Vous pouvez gagner des points en achetant un produit.  Lorsque votre invités de Niveau 1 achète un produit vous recevez 1 Pts.',
      'en':
          '3. You can earn points by purchasing a product. When your Level 1 guest purchases a product, you receive 1 point.',
    },
    'kbme15go': {
      'fr':
          '4. Si vous rencontrez des problèmes de paiement, veuillez contacter le service client.',
      'en':
          '4. If you encounter any payment problems, please contact customer service.',
    },
    '5pxkbmpn': {
      'fr': 'Roue de la Fortune',
      'en': 'Wheel of Fortune',
    },
    'q4hvtfq0': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // historique_depot
  {
    '7jz7e6pp': {
      'fr': 'Code:',
      'en': 'Code:',
    },
    '9nb7six0': {
      'fr': 'Portefeuille mobile:',
      'en': 'Mobile wallet:',
    },
    'mxtr198u': {
      'fr': 'Montant:',
      'en': 'Amount:',
    },
    '546r6dm7': {
      'fr': 'Statut:',
      'en': 'Status:',
    },
    '6ly88nue': {
      'fr': 'Temps d\'application:',
      'en': 'Application time:',
    },
    'alg29325': {
      'fr': 'Réussite',
      'en': 'Success',
    },
    'wq8b4hb0': {
      'fr': 'Echec',
      'en': 'Failure',
    },
    '44xrolrn': {
      'fr': 'Traitement...',
      'en': 'Treatment...',
    },
    'wkjq26cz': {
      'fr': 'Historique des Recharges',
      'en': 'Recharge History',
    },
    'qvqrh5z6': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // inscription
  {
    '2gdqp06m': {
      'fr': 'Connexion',
      'en': 'Login',
    },
    '5h4v1ml8': {
      'fr': 'Bonjour, bon retour sur ',
      'en': 'Hello, welcome back to',
    },
    '8pcabguz': {
      'fr': 'Haier',
      'en': 'Haier',
    },
    'hmfdy84t': {
      'fr': 'Email',
      'en': 'E-mail',
    },
    'lkqlzfx7': {
      'fr': 'Mot de passe',
      'en': 'Password',
    },
    'wj9ms9ro': {
      'fr': 'Connexion',
      'en': 'Login',
    },
    'k01rbojh': {
      'fr': 'Télécharger l\'application',
      'en': 'Download the app',
    },
    'tdxbbv2w': {
      'fr': 'Inscription',
      'en': 'Registration',
    },
    'ksso306r': {
      'fr': 'Bonjour, bienvenue chez ',
      'en': 'Hello, welcome to',
    },
    'gof67qia': {
      'fr': 'Haier',
      'en': 'Haier',
    },
    'jqb24n2o': {
      'fr': '+226',
      'en': '+226',
    },
    'mejn6ypy': {
      'fr': '+226',
      'en': '+226',
    },
    'nw6kzo9z': {
      'fr': 'Search...',
      'en': 'Search...',
    },
    'qc1ad2gw': {
      'fr': '+226',
      'en': '+226',
    },
    'diwhmsq1': {
      'fr': '+229',
      'en': '',
    },
    '54gjlqv9': {
      'fr': '+228',
      'en': '',
    },
    '1vy0kz20': {
      'fr': 'Téléphone',
      'en': 'Phone',
    },
    'w5nhbtio': {
      'fr': 'Email',
      'en': 'E-mail',
    },
    'xzgg04xa': {
      'fr': 'Mot de passe',
      'en': 'Password',
    },
    'namw7ffr': {
      'fr': 'Confirmer le  Mot de passe',
      'en': 'Confirm Password',
    },
    'q1bxofvk': {
      'fr': 'invitation',
      'en': 'invitation',
    },
    '47bch05j': {
      'fr': 'Inscription immédiate',
      'en': 'Immediate registration',
    },
    '5up5wzfy': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // historique_retrait
  {
    'dlgbbuhg': {
      'fr': 'Code:',
      'en': 'Code:',
    },
    '634c3xuj': {
      'fr': 'Nom du bénéficiaire:',
      'en': 'Name of the beneficiary:',
    },
    'zoyidbba': {
      'fr': 'Numéro de compte:',
      'en': 'Account number:',
    },
    '7o0yd154': {
      'fr': 'Portefeuille mobile:',
      'en': 'Mobile wallet:',
    },
    'r4qtwr0r': {
      'fr': 'Montant:',
      'en': 'Amount:',
    },
    'hfgir396': {
      'fr': 'Frais de dossier:',
      'en': 'Application fee:',
    },
    'ybj7uepc': {
      'fr': 'Montant reçu:',
      'en': 'Amount received:',
    },
    'vapkdjwx': {
      'fr': 'Statut:',
      'en': 'Status:',
    },
    '7ioicj1r': {
      'fr': 'Temps d\'application:',
      'en': 'Application time:',
    },
    'qkxb6n1t': {
      'fr': 'Réussite',
      'en': 'Success',
    },
    'wb08i3ul': {
      'fr': 'Echec',
      'en': 'Failure',
    },
    'ufhxu7pe': {
      'fr': 'Traitement...',
      'en': 'Treatment...',
    },
    'pku7ritu': {
      'fr': 'Historique des Recharges',
      'en': 'Recharge History',
    },
    '2qf3nen6': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // admin_acceuil
  {
    '3i8ytmeu': {
      'fr': 'Administration',
      'en': 'Administration',
    },
    '7bdi6u64': {
      'fr': 'Acceuil',
      'en': '',
    },
    '5bcfz0kg': {
      'fr': 'Vue generale',
      'en': 'General view',
    },
    'e46vz17h': {
      'fr': 'Utilisateurs totaux',
      'en': 'Total users',
    },
    '0h7cgagr': {
      'fr': 'Investisseurs actifs',
      'en': 'Active investors',
    },
    'tjfdpdzl': {
      'fr': 'Depots',
      'en': 'Depots',
    },
    'ajjjdu5f': {
      'fr': 'Total depots approuves',
      'en': 'Total deposits approved',
    },
    'xbnbr9o7': {
      'fr': 'Depots en attente',
      'en': 'Pending deposits',
    },
    'axh6svoj': {
      'fr': 'Retraits',
      'en': 'Withdrawals',
    },
    '4h6tp97s': {
      'fr': 'Total Retraits approuves',
      'en': 'Total Approved Withdrawals',
    },
    'r6i4n9y5': {
      'fr': 'Retraits en attente',
      'en': 'Withdrawals pending',
    },
    '3u7v2zr4': {
      'fr': 'Soldes',
      'en': 'Withdrawals',
    },
    'agv0yxc5': {
      'fr': 'Solde des Recharges',
      'en': 'Total Approved Withdrawals',
    },
    'jlrsij2c': {
      'fr': 'Solde des Retraits',
      'en': 'Withdrawals pending',
    },
    'v8xmnxcp': {
      'fr': 'Depots',
      'en': '',
    },
    'ksz2365n': {
      'fr': 'Historique',
      'en': 'Historical',
    },
    'jpgrdwmf': {
      'fr': 'Cliquer pour avoir plus de détails sur chaque opération',
      'en': '',
    },
    '8wvliiw4': {
      'fr': 'Filtrer (+228...)',
      'en': '',
    },
    'q1utheaq': {
      'fr': 'Dépot',
      'en': 'Deposit',
    },
    'v0r2i6n7': {
      'fr': 'ID: ',
      'en': 'ID:',
    },
    'wd99w8y5': {
      'fr': 'ID: AW92216599780',
      'en': 'ID: AW92216599780',
    },
    'm85o0b7r': {
      'fr': 'Rejeté',
      'en': 'Rejected',
    },
    'abnd2jbv': {
      'fr': 'En attente',
      'en': 'On hold',
    },
    'agvpn7he': {
      'fr': 'Succès',
      'en': 'Success',
    },
    'tf9il7ii': {
      'fr': 'Dépot',
      'en': 'Deposit',
    },
    'a6bzlvqz': {
      'fr': 'ID: ',
      'en': 'ID:',
    },
    '608s5mah': {
      'fr': 'ID: AW92216599780',
      'en': 'ID: AW92216599780',
    },
    '5r740e88': {
      'fr': 'Rejeté',
      'en': 'Rejected',
    },
    'y5tiizof': {
      'fr': 'En attente',
      'en': 'On hold',
    },
    'hwigtkbr': {
      'fr': 'Succès',
      'en': 'Success',
    },
    'c6tacd52': {
      'fr': 'Retraits',
      'en': '',
    },
    'e02idlo0': {
      'fr': 'Historique',
      'en': 'Historical',
    },
    '9c5p0k78': {
      'fr': 'Cliquer pour avoir plus de détails sur chaque opération',
      'en': '',
    },
    '6t8463b7': {
      'fr': 'Filtrer (+228...)',
      'en': '',
    },
    'ut2ovemr': {
      'fr': 'Retrait',
      'en': 'Withdrawal',
    },
    '8q1ydx8n': {
      'fr': 'ID: ',
      'en': 'ID:',
    },
    '0sb60gdk': {
      'fr': 'ID: AW92216599780',
      'en': 'ID: AW92216599780',
    },
    '1szmraza': {
      'fr': 'Rejeté',
      'en': 'Rejected',
    },
    'ng2gb9y0': {
      'fr': 'En attente',
      'en': 'On hold',
    },
    'qpyqd1qy': {
      'fr': 'Succès',
      'en': 'Success',
    },
    't3zbb0uv': {
      'fr': 'Retrait',
      'en': 'Withdrawal',
    },
    'stabuxkw': {
      'fr': 'ID: ',
      'en': 'ID:',
    },
    'ntzmc7jo': {
      'fr': 'ID: AW92216599780',
      'en': 'ID: AW92216599780',
    },
    '4pbtkbie': {
      'fr': 'Rejeté',
      'en': 'Rejected',
    },
    'shngleuh': {
      'fr': 'En attente',
      'en': 'On hold',
    },
    'cqxoeoqk': {
      'fr': 'Succès',
      'en': 'Success',
    },
    'ayj4m7oa': {
      'fr': 'Users',
      'en': '',
    },
    '3e9hwsg1': {
      'fr': 'Historique',
      'en': 'Historical',
    },
    'e5lhk4dm': {
      'fr': 'Cliquer pour avoir plus de détails sur chaque opération',
      'en': '',
    },
    'nmvs30rd': {
      'fr': 'Filtrer (email...)',
      'en': '',
    },
    'hiplchod': {
      'fr': 'code: ',
      'en': 'Godfather:',
    },
    '1g2zfds3': {
      'fr': 'Parrain: XDF542N01',
      'en': 'Sponsor: XDF542N01',
    },
    'sr1910vl': {
      'fr': 'Parrain: ',
      'en': 'Godfather:',
    },
    'kkf2mr76': {
      'fr': 'Parrain: XDF542N01',
      'en': 'Sponsor: XDF542N01',
    },
    'qhmz7o9i': {
      'fr': 'Solde',
      'en': 'Pay',
    },
    'kelzcckx': {
      'fr': 'Taille de l\'équipe',
      'en': 'Team size',
    },
    'xon5h816': {
      'fr': 'code: ',
      'en': 'Godfather:',
    },
    '3s0o3bpp': {
      'fr': 'Parrain: XDF542N01',
      'en': 'Sponsor: XDF542N01',
    },
    'h7n2fw76': {
      'fr': 'Parrain: ',
      'en': 'Godfather:',
    },
    'eozs49ss': {
      'fr': 'Parrain: XDF542N01',
      'en': 'Sponsor: XDF542N01',
    },
    'cx29frf5': {
      'fr': 'Solde',
      'en': 'Pay',
    },
    'j7t265we': {
      'fr': 'Taille de l\'équipe',
      'en': 'Team size',
    },
    'mhj9jjjs': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // admin_depots
  {
    '9dkha9q7': {
      'fr': 'Tableau de bord',
      'en': 'Dashboard',
    },
    'hpgyt5an': {
      'fr': 'Depots',
      'en': 'Depots',
    },
    'lo8p3oyu': {
      'fr': 'Retraits',
      'en': 'Withdrawals',
    },
    '11bbqlcs': {
      'fr': 'Utilisateurs',
      'en': 'Users',
    },
    '38beflij': {
      'fr': 'Historique',
      'en': 'Historical',
    },
    'nlxn59yi': {
      'fr': 'Dépot',
      'en': 'Deposit',
    },
    '7echpnfn': {
      'fr': 'ID: ',
      'en': 'ID:',
    },
    '8btom0uq': {
      'fr': 'ID: AW92216599780',
      'en': 'ID: AW92216599780',
    },
    'y8cg8lp0': {
      'fr': 'Robot pay',
      'en': 'Robot pay',
    },
    'kwylku8d': {
      'fr': 'Rejeté',
      'en': 'Rejected',
    },
    'g9hl72tn': {
      'fr': 'En attente',
      'en': 'On hold',
    },
    'uuiukxs8': {
      'fr': 'Succès',
      'en': 'Success',
    },
    'xgm8j907': {
      'fr': 'Administration',
      'en': 'Administration',
    },
    '4i2arf69': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // admin_retrait
  {
    'nvikarp1': {
      'fr': 'Tableau de bord',
      'en': 'Dashboard',
    },
    'caiejsbw': {
      'fr': 'Depots',
      'en': 'Depots',
    },
    '4kben295': {
      'fr': 'Retraits',
      'en': 'Withdrawals',
    },
    'agdz3n9o': {
      'fr': 'Utilisateurs',
      'en': 'Users',
    },
    'kg59m2gw': {
      'fr': 'Historique',
      'en': 'Historical',
    },
    'rb9c3p21': {
      'fr': 'Retrait',
      'en': 'Withdrawal',
    },
    '5iyjan0n': {
      'fr': 'ID: ',
      'en': 'ID:',
    },
    '6ig4csbp': {
      'fr': 'ID: AW92216599780',
      'en': 'ID: AW92216599780',
    },
    'wpnzar8c': {
      'fr': 'Rejeté',
      'en': 'Rejected',
    },
    't5b128zc': {
      'fr': 'En attente',
      'en': 'On hold',
    },
    '7pkuwca4': {
      'fr': 'Succès',
      'en': 'Success',
    },
    'kmp828w8': {
      'fr': 'Administration',
      'en': 'Administration',
    },
    'q4jlacyq': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // admin_users
  {
    'al3q9tje': {
      'fr': 'Tableau de bord',
      'en': 'Dashboard',
    },
    'k6ymi2gq': {
      'fr': 'Depots',
      'en': 'Depots',
    },
    'x7qq2t83': {
      'fr': 'Retraits',
      'en': 'Withdrawals',
    },
    '2ngius55': {
      'fr': 'Utilisateurs',
      'en': 'Users',
    },
    'zns8093k': {
      'fr': 'Historique',
      'en': 'Historical',
    },
    'xsq3cdiu': {
      'fr': 'Parrain: ',
      'en': 'Godfather:',
    },
    'p04kz8hl': {
      'fr': 'Parrain: XDF542N01',
      'en': 'Sponsor: XDF542N01',
    },
    'c9ljsdcl': {
      'fr': 'Solde',
      'en': 'Pay',
    },
    'ql05hhvx': {
      'fr': 'Taille de l\'équipe',
      'en': 'Team size',
    },
    'k5fv42c5': {
      'fr': 'Administration',
      'en': 'Administration',
    },
    'dixzrpz1': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // om
  {
    '0wfev13g': {
      'fr': 'No Commande:',
      'en': '',
    },
    'e6tc0k3q': {
      'fr': 'copie',
      'en': '',
    },
    'gf5vhjxe': {
      'fr': 'Montant:',
      'en': '',
    },
    'aqxl5uob': {
      'fr': 'copie',
      'en': '',
    },
    'o9m803ab': {
      'fr': 'Type de compte:',
      'en': '',
    },
    'w4jrkb7e': {
      'fr': 'Marchant ',
      'en': '',
    },
    'cejd5uhn': {
      'fr': 'copie',
      'en': '',
    },
    's4xh4v4u': {
      'fr': 'Nom du compte:',
      'en': '',
    },
    'eo30cwvi': {
      'fr': 'copie',
      'en': '',
    },
    'zo6iblf8': {
      'fr': 'Numéro de compte:',
      'en': '',
    },
    'qbtt3rs6': {
      'fr': 'copie',
      'en': '',
    },
    'q3snsh9j': {
      'fr': 'Note: ',
      'en': '',
    },
    'frht54i5': {
      'fr':
          'Copier le numéro ci dessus et envoyer l\'argent à l\'opérateur puis copier lemessage du dépot.',
      'en': '',
    },
    '0y0bja3j': {
      'fr':
          'Copier le numéro ci dessus et envoyer l\'argent à l\'opérateur puis enregistrer la capture d\'écran du dépot.',
      'en': '',
    },
    'xe46xlgx': {
      'fr': 'Veillez saisir votre numéro',
      'en': '',
    },
    'k964thg7': {
      'fr': '*',
      'en': '',
    },
    'm0dm13qh': {
      'fr': 'Montant*',
      'en': '',
    },
    'bp5wcz77': {
      'fr': 'Coller le message du dépot ici',
      'en': '',
    },
    '24l9omkf': {
      'fr': '*',
      'en': '',
    },
    'fepv1k8p': {
      'fr': 'Montant*',
      'en': '',
    },
    '65245zim': {
      'fr': 'Veillez  coller  le message de votre transaction',
      'en': '',
    },
    'esova2ab': {
      'fr': 'Envoyer',
      'en': '',
    },
    'kkxmjg5j': {
      'fr':
          'Après avoir effectuer la transaction veillez patientez 10 minutes et vous le recevrez dans votre compte.',
      'en': '',
    },
    'vz6t8mqg': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // mtn
  {
    '36guxiws': {
      'fr': 'No Commande:',
      'en': '',
    },
    '5cbw4jjt': {
      'fr': 'copie',
      'en': '',
    },
    '6uvugrf5': {
      'fr': 'Montant:',
      'en': '',
    },
    'pqsw9kf0': {
      'fr': 'copie',
      'en': '',
    },
    'dlz8b8et': {
      'fr': 'Type de compte:',
      'en': '',
    },
    'dxnwhvki': {
      'fr': 'Marchant MTN',
      'en': '',
    },
    'f4xzt0dl': {
      'fr': 'copie',
      'en': '',
    },
    'tlube55v': {
      'fr': 'Nom du compte:',
      'en': '',
    },
    'up5z13g6': {
      'fr': 'LUCIEN MONEY',
      'en': '',
    },
    'bj7vi39f': {
      'fr': 'copie',
      'en': '',
    },
    'g7puktxz': {
      'fr': 'Numéro de compte:',
      'en': '',
    },
    'mj3k6kez': {
      'fr': '650066212',
      'en': '650066212',
    },
    'znu6tubw': {
      'fr': 'copie',
      'en': '',
    },
    'inafo6z5': {
      'fr': 'Montant*',
      'en': '',
    },
    '8iwqwp09': {
      'fr': 'Veillez  saisir le montant de votre transaction',
      'en': '',
    },
    'kblcdz5r': {
      'fr':
          'Please send your payment voucher to your custumer service manager! thank you',
      'en': '',
    },
    'lq2528za': {
      'fr':
          'Après avoir effectuer la transaction veillez patientez 10 minutes et vous le recevrez dans votre compte.',
      'en': '',
    },
    'n1e4o3r0': {
      'fr': 'Envoyer',
      'en': '',
    },
    'af1bt9ro': {
      'fr': 'Home',
      'en': 'Home',
    },
  },
  // Navbar1
  {
    'da2zwpki': {
      'fr': 'Acceuil',
      'en': 'Home',
    },
    'og0tgce8': {
      'fr': 'Produits',
      'en': 'Products',
    },
    'vq6jlp1s': {
      'fr': 'Equipe',
      'en': 'Team',
    },
    'anr4je9w': {
      'fr': 'Profile',
      'en': 'Profile',
    },
  },
  // succes_achat
  {
    'r5qnu25t': {
      'fr': 'Paiement réussi',
      'en': 'Payment successful',
    },
    '4jndg7rs': {
      'fr': 'Confirmer',
      'en': 'Confirm',
    },
  },
  // succes_collecte
  {
    'pds455mt': {
      'fr': 'Félicitation vous avez reçu ',
      'en': 'Congratulations, you have received',
    },
    'uw3u8itv': {
      'fr': 'CFA',
      'en': 'CFA',
    },
    '6ns3aif6': {
      'fr': 'Félicitation vous avez reçu ',
      'en': 'Congratulations, you have received',
    },
    'fmrww20n': {
      'fr': 'Confirmer',
      'en': 'Confirm',
    },
  },
  // copie
  {
    'f73elulu': {
      'fr': 'Copie réussie',
      'en': 'Successful copy',
    },
  },
  // vide
  {
    '9v1i0mm8': {
      'fr': 'Liste vide',
      'en': 'Empty list',
    },
  },
  // bonus
  {
    'srlycbaq': {
      'fr': 'Veillez saisir le code d\'échange',
      'en': 'Please enter the exchange code',
    },
    'mn9efxef': {
      'fr': 'Êtes-vous sûr de vouloir acheter ce produit',
      'en': 'Are you sure you want to buy this product?',
    },
    'hrxstbuv': {
      'fr': 'Veillez saisir le code d\'échange',
      'en': 'Please enter the exchange code',
    },
    'sqn995n9': {
      'fr': 'Annuler',
      'en': 'Cancel',
    },
    'pw54mh8h': {
      'fr': 'Confirmer',
      'en': 'Confirm',
    },
  },
  // success_retrait
  {
    'w8jbzmqz': {
      'fr': 'Conseil',
      'en': 'Advice',
    },
    'd5b7u023': {
      'fr': 'Retrait réuissi',
      'en': 'Withdrawal successful',
    },
  },
  // service_client
  {
    '827tobaq': {
      'fr': 'Assistance client',
      'en': 'Customer support',
    },
    'sbupkds6': {
      'fr': 'Canal télégram',
      'en': 'Customer support',
    },
  },
  // Navbar2
  {
    'm27n2pjr': {
      'fr': 'Acceuil',
      'en': 'Home',
    },
    'ufj0m831': {
      'fr': 'Produits',
      'en': 'Products',
    },
    'zc884llq': {
      'fr': 'Equipe',
      'en': 'Team',
    },
    'igv1jskd': {
      'fr': 'Profile',
      'en': 'Profile',
    },
  },
  // Navbar3
  {
    'anf6318o': {
      'fr': 'Acceuil',
      'en': 'Home',
    },
    '9en2pwtn': {
      'fr': 'Produits',
      'en': 'Products',
    },
    '1hyc751d': {
      'fr': 'Equipe',
      'en': 'Team',
    },
    'q6902lcu': {
      'fr': 'Profile',
      'en': 'Profile',
    },
  },
  // Navbar4
  {
    't8qx9eg5': {
      'fr': 'Acceuil',
      'en': 'Home',
    },
    'h24xc5yf': {
      'fr': 'Produits',
      'en': 'Products',
    },
    'mxmlko4x': {
      'fr': 'Equipe',
      'en': 'Team',
    },
    '039iv6kt': {
      'fr': 'Profile',
      'en': 'Profile',
    },
  },
  // Navbar5
  {
    '09z27h1y': {
      'fr': 'Acceuil',
      'en': 'Home',
    },
    'ckxlkkwa': {
      'fr': 'Produits',
      'en': 'Products',
    },
    'uiet545w': {
      'fr': 'Equipe',
      'en': 'Team',
    },
    'jzr95axy': {
      'fr': 'Profile',
      'en': 'Profile',
    },
  },
  // notification
  {
    'hxyi90cr': {
      'fr': 'Centre de Notifications',
      'en': 'Notification Center',
    },
    'wqd7n5sx': {
      'fr': 'Lisa Andrew ',
      'en': 'Lisa Andrew',
    },
    's2323eeb': {
      'fr': '@SupportHaier',
      'en': '@SupportHaier',
    },
    '8iq2wb6v': {
      'fr':
          'FlutterFlow is a visual development platform that allows you to easily create beautiful and responsive user interfaces for your mobile and web applications. ',
      'en':
          'FlutterFlow is a visual development platform that allows you to easily create beautiful and responsive user interfaces for your mobile and web applications.',
    },
  },
  // affiche
  {
    '445yc9rx': {
      'fr':
          'Rejoignez notre Canal officiel pour recevoir des récompenses en espèces quotidiens.',
      'en': 'Join our official channel to receive daily cash rewards.',
    },
    'mxl6w0aw': {
      'fr':
          'Cliquez sur le lien pour rejoindre notre canal télégram participez aux évènements  et gagner jusqu\'à 5 000 CFA de bonus.',
      'en': 'WhatsApp\nGroup chat',
    },
  },
  // methode
  {
    '7eay3ftw': {
      'fr': 'Méthode de paiement',
      'en': '',
    },
  },
  // details_depot
  {
    'p5slaouz': {
      'fr': 'ID dépot:',
      'en': '',
    },
    'amru8m40': {
      'fr': 'Date et heure du dépot:',
      'en': '',
    },
    'nmhmxnyg': {
      'fr': 'Opérateur mobile:',
      'en': '',
    },
    'nqwamzy3': {
      'fr': 'Numéro du payeur:',
      'en': '',
    },
    'tnlkaddx': {
      'fr': 'Statut de l\'opération:',
      'en': '',
    },
    'x5vrdm0u': {
      'fr': 'Rejeté',
      'en': 'Rejected',
    },
    'z9gfgtcy': {
      'fr': 'En attente',
      'en': 'On hold',
    },
    '55ps2ux5': {
      'fr': 'Succès',
      'en': 'Success',
    },
    'ej8n0eh5': {
      'fr': 'Valider la recharge',
      'en': '',
    },
    'nipn0w0l': {
      'fr': 'Rejeté',
      'en': '',
    },
  },
  // details_retrait
  {
    'fwl3riba': {
      'fr': 'ID retrait:',
      'en': '',
    },
    '06m61xmk': {
      'fr': 'Date et heure du retrait:',
      'en': '',
    },
    'y9rwf7t8': {
      'fr': 'Opérateur mobile:',
      'en': '',
    },
    '2gesb0ww': {
      'fr': 'Numéro de retrait',
      'en': '',
    },
    'pqxh22rv': {
      'fr': 'Nom du compte',
      'en': '',
    },
    '1mpeozwl': {
      'fr': 'Frais de retrait:',
      'en': '',
    },
    'y44kdf7p': {
      'fr': 'Statut de l\'opération:',
      'en': '',
    },
    'hfh4pjuj': {
      'fr': 'Rejeté',
      'en': 'Rejected',
    },
    '9lqenwnl': {
      'fr': 'En attente',
      'en': 'On hold',
    },
    'a5albrzi': {
      'fr': 'Succès',
      'en': 'Success',
    },
    'sa45khoh': {
      'fr': 'Retrait effectué',
      'en': '',
    },
    '2djm2r6t': {
      'fr': 'Rejeté',
      'en': '',
    },
  },
  // details_user
  {
    '3267gs3z': {
      'fr': 'Email:',
      'en': '',
    },
    '60k9du2g': {
      'fr': 'Date d\'inscription:',
      'en': '',
    },
    'juj493az': {
      'fr': 'ID:',
      'en': '',
    },
    'od9svoux': {
      'fr': 'Niveau 1',
      'en': '',
    },
    '1i1x2fjg': {
      'fr': 'Niveau 2',
      'en': '',
    },
    'wkulbrg6': {
      'fr': 'Niveau 3',
      'en': '',
    },
    '738f5ddc': {
      'fr': 'Solde',
      'en': '',
    },
    'zsp9ew6w': {
      'fr': ' FCFA',
      'en': '',
    },
    '70scj4n4': {
      'fr': 'Nouveau solde',
      'en': '',
    },
    'xx80677b': {
      'fr': 'OK',
      'en': '',
    },
    'cp0g9zg0': {
      'fr': 'Attribuer un produit',
      'en': '',
    },
    'npyppek4': {
      'fr': 'OK',
      'en': '',
    },
    'bnabtu6k': {
      'fr': 'Nommer admin',
      'en': '',
    },
    '0chbi9pm': {
      'fr': 'Bannir',
      'en': '',
    },
  },
  // produit_liste
  {
    'qo6h2zt7': {
      'fr': 'Prix du produit: ',
      'en': '',
    },
    'p4h0k67g': {
      'fr': 'Revenu quotidien',
      'en': '',
    },
    'k692wh49': {
      'fr': ' CFA',
      'en': '',
    },
  },
  // methoderetrait
  {
    'dlxn3lug': {
      'fr': 'Méthode de retrait',
      'en': '',
    },
  },
  // message_depot
  {
    'wmsep2lc': {
      'fr':
          'Votre demande de recharge à bien été reçu et est en cour de traitement vous recevrez votre recharge au bout de 10 minutes maximum.',
      'en': '',
    },
  },
  // Miscellaneous
  {
    'xizqy9ow': {
      'fr': '',
      'en': '',
    },
    'ec3rj7gp': {
      'fr': '',
      'en': '',
    },
    'd6xnty6r': {
      'fr': '',
      'en': '',
    },
    'et4cps0y': {
      'fr': '',
      'en': '',
    },
    'inyr9zlo': {
      'fr': '',
      'en': '',
    },
    'k45fo6zx': {
      'fr': '',
      'en': '',
    },
    'o3mk0c5b': {
      'fr': '',
      'en': '',
    },
    'qghso7sm': {
      'fr': '',
      'en': '',
    },
    'wesc7c9z': {
      'fr': '',
      'en': '',
    },
    '5q9jnniw': {
      'fr': '',
      'en': '',
    },
    '6ubott7t': {
      'fr': '',
      'en': '',
    },
    '38gzj3b9': {
      'fr': '',
      'en': '',
    },
    '7mbn47u1': {
      'fr': '',
      'en': '',
    },
    'gzr0eejj': {
      'fr': '',
      'en': '',
    },
    'prs3y6y9': {
      'fr': '',
      'en': '',
    },
    '5monc9gx': {
      'fr': '',
      'en': '',
    },
    '2mma13ar': {
      'fr': '',
      'en': '',
    },
    'dk6lifwp': {
      'fr': '',
      'en': '',
    },
    'pa7h46rw': {
      'fr': '',
      'en': '',
    },
    'jw4zejq8': {
      'fr': '',
      'en': '',
    },
    '4zimpjsv': {
      'fr': '',
      'en': '',
    },
    '6osi6ar6': {
      'fr': '',
      'en': '',
    },
    'gxlrr8oy': {
      'fr': '',
      'en': '',
    },
    '83b2qf8d': {
      'fr': '',
      'en': '',
    },
    'eo29xv4h': {
      'fr': '',
      'en': '',
    },
    'u8wawi4f': {
      'fr': '',
      'en': '',
    },
    '0d2zs81v': {
      'fr': '',
      'en': '',
    },
    '4q4ugfjr': {
      'fr': '',
      'en': '',
    },
  },
].reduce((a, b) => a..addAll(b));
