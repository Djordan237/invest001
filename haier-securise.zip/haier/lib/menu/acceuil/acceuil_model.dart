import '/components/affiche_widget.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/navbar/navbar1/navbar1_widget.dart';
import 'dart:math';
import 'dart:ui';
import '/index.dart';
import 'acceuil_widget.dart' show AcceuilWidget;
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:simple_gradient_text/simple_gradient_text.dart';

class AcceuilModel extends FlutterFlowModel<AcceuilWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Carousel widget.
  CarouselSliderController? carouselController1;
  int carouselCurrentIndex1 = 1;

  // State field(s) for Carousel widget.
  CarouselSliderController? carouselController2;
  int carouselCurrentIndex2 = 1;

  // Model for Navbar1 component.
  late Navbar1Model navbar1Model;

  @override
  void initState(BuildContext context) {
    navbar1Model = createModel(context, () => Navbar1Model());
  }

  @override
  void dispose() {
    navbar1Model.dispose();
  }
}
