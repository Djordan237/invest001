import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/navbar/navbar2/navbar2_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'produits_widget.dart' show ProduitsWidget;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ProduitsModel extends FlutterFlowModel<ProduitsWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Navbar2 component.
  late Navbar2Model navbar2Model;

  @override
  void initState(BuildContext context) {
    navbar2Model = createModel(context, () => Navbar2Model());
  }

  @override
  void dispose() {
    navbar2Model.dispose();
  }
}
