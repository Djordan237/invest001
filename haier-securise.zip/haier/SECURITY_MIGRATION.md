# Déploiement de la sécurisation

Cette version ne doit pas être publiée avant l’application de la migration
Supabase suivante :

`supabase/migrations/20260928_security_and_balance_integrity.sql`

## Ce que la migration protège

- supprime la colonne historique `user.mp`, qui contenait les mots de passe en
  clair ;
- verrouille la ligne utilisateur pendant chaque opération de solde ;
- déplace l’achat, la collecte de revenu, le retrait, la loterie et les codes
  bonus dans des fonctions PostgreSQL transactionnelles ;
- empêche un utilisateur de modifier directement son solde, ses rôles ou ses
  produits achetés ;
- limite les écrans et les données d’administration aux comptes admin ;
- ajoute les politiques RLS de base sur les tables financières.

## Ordre de déploiement

1. Exporter une sauvegarde Supabase avant toute modification.
2. Exécuter la migration dans l’éditeur SQL Supabase.
3. Vérifier qu’un compte standard peut se connecter, consulter ses données,
   acheter un produit, collecter un revenu et demander un retrait.
4. Vérifier qu’un compte standard ne peut pas ouvrir les routes admin.
5. Vérifier qu’un compte admin peut traiter les dépôts et les retraits.
6. Publier ensuite l’export Flutter mis à jour.

La migration est volontairement séparée du code Flutter : elle doit être
appliquée sur le projet Supabase réellement utilisé par l’application. Aucune
clé ou valeur sensible n’est stockée dans le dépôt.