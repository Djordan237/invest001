-- Haier security and balance integrity baseline.
-- Apply this migration in Supabase SQL Editor before releasing the matching
-- Flutter build. It deliberately removes the legacy plaintext password field.

create or replace function public.is_app_admin()
returns boolean
language sql
security definer
set search_path = public, pg_temp
stable
as $$
  select exists (
    select 1
    from public."user" u
    where u.id::text = auth.uid()::text
      and (coalesce(u.admin, false) or coalesce(u.admin_burkina, false))
  );
$$;

revoke all on function public.is_app_admin() from public;
grant execute on function public.is_app_admin() to authenticated;

create or replace function public.apply_referral_earnings(
  p_user_id uuid,
  p_amount numeric
)
returns void
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_user public."user"%rowtype;
  v_sponsor public."user"%rowtype;
  v_code text;
  v_rate numeric;
  v_level integer;
begin
  select * into v_user from public."user" where id::text = p_user_id::text;
  v_code := v_user.code_parrain;

  for v_level in 1..3 loop
    exit when v_code is null or trim(v_code) = '';

    select *
      into v_sponsor
      from public."user"
     where code_invitation = v_code
     for update;

    exit when not found;
    v_rate := case v_level when 1 then 0.25 when 2 then 0.03 else 0.02 end;

    update public."user"
       set solde = coalesce(solde, 0) + p_amount * v_rate,
           TT_benefice = coalesce(TT_benefice, 0) + p_amount * v_rate,
           benef_lv1 = case when v_level = 1 then coalesce(benef_lv1, 0) + p_amount * v_rate else benef_lv1 end,
           benef_lv2 = case when v_level = 2 then coalesce(benef_lv2, 0) + p_amount * v_rate else benef_lv2 end,
           benef_lv3 = case when v_level = 3 then coalesce(benef_lv3, 0) + p_amount * v_rate else benef_lv3 end
     where id = v_sponsor.id;

    v_code := v_sponsor.code_parrain;
  end loop;
end;
$$;

create or replace function public.purchase_product(p_product_id bigint)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_user public."user"%rowtype;
  v_product public.produit%rowtype;
begin
  if auth.uid() is null then
    raise exception 'AUTH_REQUIRED';
  end if;

  select *
    into v_user
    from public."user"
   where id::text = auth.uid()::text
   for update;

  if not found then
    raise exception 'USER_PROFILE_NOT_FOUND';
  end if;

  select *
    into v_product
    from public.produit
   where id = p_product_id
   for share;

  if not found then
    raise exception 'PRODUCT_NOT_FOUND';
  end if;

  if coalesce(v_product.prix, 0) <= 0 then
    raise exception 'INVALID_PRODUCT_PRICE';
  end if;

  if coalesce(v_user.solde, 0) < v_product.prix then
    raise exception 'INSUFFICIENT_BALANCE';
  end if;

  update public."user"
     set solde = coalesce(solde, 0) - v_product.prix,
         point = coalesce(point, 0) + coalesce(v_product.points, 0),
         tt_produits = coalesce(tt_produits, 0) + 1
   where id::text = auth.uid()::text;

  insert into public.produit_user (
    id, nom, cycle, revenu_jour, total_recu, total_gains, prix, taux, image,
    collecte
  )
  values (
    auth.uid(), v_product.nom_produit, v_product.cycle, v_product.revenu_jour,
    0, v_product.revenu_tt, v_product.prix, v_product.interet,
    v_product.image_produit, false
  );

  perform public.apply_referral_earnings(auth.uid(), v_product.prix);

  return jsonb_build_object(
    'product_id', v_product.id,
    'price', v_product.prix,
    'new_balance', (select solde from public."user" where id::text = auth.uid()::text),
    'points_awarded', coalesce(v_product.points, 0)
  );
end;
$$;

create or replace function public.request_withdrawal(
  p_amount numeric,
  p_address text,
  p_method text,
  p_user_name text
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_user public."user"%rowtype;
  v_fee_rate numeric;
  v_fee numeric;
  v_withdrawal public.retrait%rowtype;
begin
  if auth.uid() is null then
    raise exception 'AUTH_REQUIRED';
  end if;
  if p_amount is null or p_amount < 1000 then
    raise exception 'MINIMUM_WITHDRAWAL_IS_1000';
  end if;
  if nullif(trim(p_address), '') is null or nullif(trim(p_method), '') is null then
    raise exception 'WITHDRAWAL_DETAILS_REQUIRED';
  end if;

  select *
    into v_user
    from public."user"
   where id::text = auth.uid()::text
   for update;

  if not found then
    raise exception 'USER_PROFILE_NOT_FOUND';
  end if;
  if coalesce(v_user.retrait_visible, false) = false then
    raise exception 'WITHDRAWAL_NOT_AVAILABLE';
  end if;
  if coalesce(v_user.solde, 0) < p_amount then
    raise exception 'INSUFFICIENT_BALANCE';
  end if;

  select coalesce(frais_retrait, 0)
    into v_fee_rate
    from public."détails"
   where id = 1;

  v_fee := round(p_amount * coalesce(v_fee_rate, 0), 2);

  insert into public.retrait (
    id, id_retrait, adresse, montant_retrait, montant_recu, methode,
    "statut_succès", statut_echec, statut_attente, nom_user, frais
  )
  values (
    auth.uid(),
    'AW' || to_char(clock_timestamp(), 'YYYYMMDDHH24MISSMS'),
    trim(p_address),
    p_amount,
    p_amount - v_fee,
    trim(p_method),
    false,
    false,
    true,
    nullif(trim(p_user_name), ''),
    v_fee
  )
  returning * into v_withdrawal;

  update public."user"
     set solde = coalesce(solde, 0) - p_amount,
         retrait_visible = false,
         tt_retraits = coalesce(tt_retraits, 0) + p_amount
   where id::text = auth.uid()::text;

  return jsonb_build_object(
    'withdrawal_number', v_withdrawal.num,
    'amount', p_amount,
    'fee', v_fee,
    'received_amount', p_amount - v_fee,
    'status', 'pending'
  );
end;
$$;

create or replace function public.claim_lottery_prize(p_prize_name text)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_user public."user"%rowtype;
  v_amount numeric;
begin
  if auth.uid() is null then
    raise exception 'AUTH_REQUIRED';
  end if;

  v_amount := case trim(p_prize_name)
    when '500 CFA' then 500
    when '2 000 CFA' then 2000
    when '2000 CFA' then 2000
    when '20 000 CFA' then 20000
    else null
  end;

  if v_amount is null then
    raise exception 'PRIZE_NOT_ELIGIBLE';
  end if;

  select *
    into v_user
    from public."user"
   where id::text = auth.uid()::text
   for update;

  if not found then
    raise exception 'USER_PROFILE_NOT_FOUND';
  end if;
  if coalesce(v_user.point, 0) < 1 then
    raise exception 'INSUFFICIENT_POINTS';
  end if;

  update public."user"
     set point = coalesce(point, 0) - 1,
         solde = coalesce(solde, 0) + v_amount,
         tt_gains = coalesce(tt_gains, 0) + v_amount
   where id::text = auth.uid()::text;

  return jsonb_build_object(
    'prize_name', trim(p_prize_name),
    'amount', v_amount,
    'new_balance', (select solde from public."user" where id::text = auth.uid()::text)
  );
end;
$$;

create or replace function public.redeem_bonus_code(p_code text)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_user public."user"%rowtype;
  v_bonus public.code_bonus%rowtype;
begin
  if auth.uid() is null then
    raise exception 'AUTH_REQUIRED';
  end if;
  if nullif(trim(p_code), '') is null then
    raise exception 'BONUS_CODE_REQUIRED';
  end if;

  select *
    into v_user
    from public."user"
   where id::text = auth.uid()::text
   for update;
  if not found then
    raise exception 'USER_PROFILE_NOT_FOUND';
  end if;

  select *
    into v_bonus
    from public.code_bonus
   where upper(code) = upper(trim(p_code))
   for update;
  if not found or coalesce(v_bonus.nbre_activation, 0) < 1 then
    raise exception 'BONUS_CODE_INVALID_OR_EXHAUSTED';
  end if;

  update public.code_bonus
     set nbre_activation = nbre_activation - 1
   where id = v_bonus.id;

  update public."user"
     set solde = coalesce(solde, 0) + coalesce(v_bonus.montant, 0),
         bonus_actif = false
   where id::text = auth.uid()::text;

  return jsonb_build_object(
    'bonus', coalesce(v_bonus.montant, 0),
    'new_balance', (select solde from public."user" where id::text = auth.uid()::text)
  );
end;
$$;

create or replace function public.collect_product_revenue(
  p_product_user_num bigint
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_user public."user"%rowtype;
  v_product public.produit_user%rowtype;
begin
  if auth.uid() is null then
    raise exception 'AUTH_REQUIRED';
  end if;

  select *
    into v_user
    from public."user"
   where id::text = auth.uid()::text
   for update;
  if not found then
    raise exception 'USER_PROFILE_NOT_FOUND';
  end if;

  select *
    into v_product
    from public.produit_user
   where num = p_product_user_num
     and id::text = auth.uid()::text
   for update;
  if not found or coalesce(v_product.collecte, false) then
    raise exception 'REVENUE_ALREADY_COLLECTED';
  end if;
  if coalesce(v_product.cycle, 0) <= 0 then
    raise exception 'PRODUCT_CYCLE_FINISHED';
  end if;
  if coalesce(v_product.revenu_jour, 0) < 0 then
    raise exception 'INVALID_REVENUE';
  end if;

  update public.produit_user
     set collecte = true,
         total_recu = coalesce(total_recu, 0) + coalesce(revenu_jour, 0),
         cycle = cycle - 1
   where num = p_product_user_num
     and id::text = auth.uid()::text;

  update public."user"
     set solde = coalesce(solde, 0) + coalesce(v_product.revenu_jour, 0),
         tt_gains = coalesce(tt_gains, 0) + coalesce(v_product.revenu_jour, 0)
   where id::text = auth.uid()::text;

  perform public.apply_referral_earnings(
    auth.uid(),
    coalesce(v_product.revenu_jour, 0)
  );

  return jsonb_build_object(
    'amount', coalesce(v_product.revenu_jour, 0),
    'remaining_cycle', v_product.cycle - 1
  );
end;
$$;

revoke all on function public.purchase_product(bigint) from public;
revoke all on function public.apply_referral_earnings(uuid, numeric) from public;
revoke all on function public.request_withdrawal(numeric, text, text, text) from public;
revoke all on function public.claim_lottery_prize(text) from public;
revoke all on function public.redeem_bonus_code(text) from public;
revoke all on function public.collect_product_revenue(bigint) from public;
grant execute on function public.purchase_product(bigint) to authenticated;
grant execute on function public.request_withdrawal(numeric, text, text, text) to authenticated;
grant execute on function public.claim_lottery_prize(text) to authenticated;
grant execute on function public.redeem_bonus_code(text) to authenticated;
grant execute on function public.collect_product_revenue(bigint) to authenticated;

-- The old column contained user passwords and must not exist after deployment.
alter table if exists public."user" drop column if exists mp;

-- RLS protects reads and prevents clients from directly mutating balances.
alter table if exists public."user" enable row level security;
alter table if exists public.produit enable row level security;
alter table if exists public.produit_user enable row level security;
alter table if exists public.depot enable row level security;
alter table if exists public.retrait enable row level security;
alter table if exists public.notifications enable row level security;
alter table if exists public.partage_user enable row level security;

drop policy if exists user_select_own_or_admin on public."user";
create policy user_select_own_or_admin on public."user"
  for select to authenticated
  using (id::text = auth.uid()::text or public.is_app_admin());

drop policy if exists user_insert_own on public."user";
create policy user_insert_own on public."user"
  for insert to authenticated
  with check (id::text = auth.uid()::text and coalesce(admin, false) = false and coalesce(admin_burkina, false) = false);

drop policy if exists user_admin_update on public."user";
create policy user_admin_update on public."user"
  for update to authenticated
  using (public.is_app_admin())
  with check (public.is_app_admin());

drop policy if exists user_admin_delete on public."user";
create policy user_admin_delete on public."user"
  for delete to authenticated
  using (public.is_app_admin());

drop policy if exists produit_read_authenticated on public.produit;
create policy produit_read_authenticated on public.produit
  for select to authenticated using (true);

drop policy if exists produit_user_select_own on public.produit_user;
create policy produit_user_select_own on public.produit_user
  for select to authenticated using (id::text = auth.uid()::text or public.is_app_admin());

drop policy if exists produit_user_admin_insert on public.produit_user;
create policy produit_user_admin_insert on public.produit_user
  for insert to authenticated
  with check (public.is_app_admin());

drop policy if exists depot_select_own_or_admin on public.depot;
create policy depot_select_own_or_admin on public.depot
  for select to authenticated using (id::text = auth.uid()::text or public.is_app_admin());

drop policy if exists depot_insert_own on public.depot;
create policy depot_insert_own on public.depot
  for insert to authenticated with check (id::text = auth.uid()::text);

drop policy if exists depot_admin_update on public.depot;
create policy depot_admin_update on public.depot
  for update to authenticated using (public.is_app_admin()) with check (public.is_app_admin());

drop policy if exists retrait_select_own_or_admin on public.retrait;
create policy retrait_select_own_or_admin on public.retrait
  for select to authenticated using (id::text = auth.uid()::text or public.is_app_admin());

drop policy if exists retrait_admin_update on public.retrait;
create policy retrait_admin_update on public.retrait
  for update to authenticated using (public.is_app_admin()) with check (public.is_app_admin());

drop policy if exists notifications_select_own_or_admin on public.notifications;
create policy notifications_select_own_or_admin on public.notifications
  for select to authenticated using (id::text = auth.uid()::text or public.is_app_admin());

drop policy if exists notifications_insert_own on public.notifications;
create policy notifications_insert_own on public.notifications
  for insert to authenticated with check (id::text = auth.uid()::text);

drop policy if exists partage_user_select_own_or_admin on public.partage_user;
create policy partage_user_select_own_or_admin on public.partage_user
  for select to authenticated using ("userId" = auth.uid()::text or public.is_app_admin());

drop policy if exists partage_user_insert_own on public.partage_user;
create policy partage_user_insert_own on public.partage_user
  for insert to authenticated with check ("userId" = auth.uid()::text);