package com.mycompany.haier

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
