# Haier

Application FlutterFlow de gestion de produits, de recharges, de retraits et de
parrainage, connectée à Supabase.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `haier/` — export FlutterFlow source de l’application mobile/web.
- `haier/supabase/migrations/` — migrations SQL à appliquer au projet Supabase.
- `haier/lib/security/secure_operations.dart` — appels client des opérations de
  solde transactionnelles.
- `haier/lib/auth/admin_guard.dart` — garde d’accès aux écrans administrateur.

## Architecture decisions

- Les opérations qui modifient un solde passent par des fonctions PostgreSQL
  `SECURITY DEFINER` avec verrouillage de ligne.
- Les écrans admin sont protégés dans le routeur et par une vérification du rôle
  dans l’application.
- La migration Supabase doit être appliquée avant de publier le code Flutter
  correspondant.

## Product

Les utilisateurs peuvent s’inscrire, gérer un solde, acheter des produits,
collecter des revenus, demander un retrait et participer au parrainage. Les
administrateurs traitent les opérations et gèrent les utilisateurs.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Ne pas publier `haier/` avant d’avoir appliqué et vérifié
  `haier/supabase/migrations/20260928_security_and_balance_integrity.sql`.
- Le champ historique `user.mp` est supprimé par la migration ; aucun mot de
  passe ne doit être écrit dans la table métier `user`.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
